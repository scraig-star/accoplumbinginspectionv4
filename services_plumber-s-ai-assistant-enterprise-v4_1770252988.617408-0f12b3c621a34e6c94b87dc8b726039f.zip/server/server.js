require('dotenv').config();
const express = require('express');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const WebSocket = require('ws');
const cors = require('cors');
const { Storage } = require('@google-cloud/storage');
const { Firestore } = require('@google-cloud/firestore');

const app = express();
const port = process.env.PORT || 8080;

const storage = new Storage();
const firestore = new Firestore();
const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "acco-inspection-training-data";

console.log('[STARTUP] ACCO Backend Server v98 Initializing...');
console.log('[CONFIG] Port:', port);
console.log('[CONFIG] Bucket:', BUCKET_NAME);

app.use(cors({ origin: '*', methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'] }));
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

app.get('/health', (req, res) => {
  console.log('[HEALTH] Check passed');
  res.status(200).send('OK');
});

app.get('/api/v1/ping', async (req, res) => {
  try {
    const checks = { storage: false, firestore: false };
    try {
      const [exists] = await storage.bucket(BUCKET_NAME).exists();
      checks.storage = exists;
    } catch (e) {}
    try {
      await firestore.collection('_health').doc('check').set({ timestamp: new Date().toISOString() });
      checks.firestore = true;
    } catch (e) {}
    res.status(200).json({
      status: checks.storage && checks.firestore ? 'healthy' : 'degraded',
      infrastructure: {
        storage: checks.storage ? 'connected' : 'disconnected',
        firestore: checks.firestore ? 'connected' : 'disconnected',
        gemini_proxy: apiKey ? 'ready' : 'missing_key'
      },
      version: '98.0.0'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/v1/upload-image', async (req, res) => {
  try {
    const { image, filename, bucket: bucketName } = req.body;
    if (!image) return res.status(400).json({ error: "Missing image data" });
    if (!filename) return res.status(400).json({ error: "Missing filename" });
    
    const targetBucket = storage.bucket(bucketName || BUCKET_NAME);
    await targetBucket.file(`images/${filename}`).save(Buffer.from(image, 'base64'), {
      metadata: { contentType: 'image/jpeg' },
      resumable: false
    });
    
    const gcsUri = `gs://${bucketName || BUCKET_NAME}/images/${filename}`;
    res.status(200).json({ success: true, gcsUri, filename });
  } catch (error) {
    res.status(500).json({ error: "Storage upload failed", details: error.message });
  }
});

app.post('/api/v1/log-correction', async (req, res) => {
  try {
    const correctionData = {
      ...req.body,
      serverTimestamp: Firestore.FieldValue.serverTimestamp(),
      status: req.body.status || 'pending_jsonl_export'
    };
    const docRef = await firestore.collection('corrections').add(correctionData);
    res.status(200).json({ success: true, firestoreId: docRef.id });
  } catch (error) {
    res.status(500).json({ error: "Firestore save failed", details: error.message });
  }
});

const distPath = path.join(__dirname, 'dist');
console.log('[STATIC] Serving from:', distPath);

app.use(express.static(distPath, {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.tsx') || filePath.endsWith('.ts')) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    } else if (filePath.endsWith('.js')) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    } else if (filePath.endsWith('.css')) {
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
    }
  }
}));

const publicPath = path.join(__dirname, 'public');
if (fs.existsSync(publicPath)) {
  app.use(express.static(publicPath));
}

app.use('/api-proxy', async (req, res, next) => {
  if (req.headers.upgrade && req.headers.upgrade.toLowerCase() === 'websocket') return next();
  try {
    const targetPath = req.url.replace(/^\/+/, '');
    const geminiUrl = `https://generativelanguage.googleapis.com/${targetPath}`;
    const response = await axios({
      method: req.method,
      url: geminiUrl,
      headers: { 'X-Goog-Api-Key': apiKey, 'Content-Type': req.headers['content-type'] || 'application/json' },
      data: req.body,
      responseType: 'stream',
      validateStatus: () => true
    });
    for (const header in response.headers) res.setHeader(header, response.headers[header]);
    res.status(response.status);
    response.data.pipe(res);
  } catch (error) {
    if (!res.headersSent) res.status(500).json({ error: 'Gemini proxy error' });
  }
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found', path: req.path });
  }
  const indexPath = path.join(distPath, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(404).send('App files not found');
  }
});

const server = app.listen(port, '0.0.0.0', () => {
  console.log('\n========================================');
  console.log('  ACCO Backend Running');
  console.log('  Port:', port);
  console.log('========================================\n');
});

const wss = new WebSocket.Server({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const requestUrl = new URL(request.url, `http://${request.headers.host}`);
  if (requestUrl.pathname.includes('/api-proxy/')) {
    wss.handleUpgrade(request, socket, head, (clientWs) => {
      const pathParts = requestUrl.pathname.split('/api-proxy');
      const geminiWsUrl = `wss://generativelanguage.googleapis.com${pathParts[pathParts.length-1]}?${requestUrl.searchParams.toString()}&key=${apiKey}`;
      const geminiWs = new WebSocket(geminiWsUrl);
      geminiWs.on('message', (msg) => { if (clientWs.readyState === WebSocket.OPEN) clientWs.send(msg); });
      clientWs.on('message', (msg) => { if (geminiWs.readyState === WebSocket.OPEN) geminiWs.send(msg); });
      geminiWs.on('close', (code, reason) => { if (clientWs.readyState === WebSocket.OPEN) clientWs.close(code, reason.toString()); });
      clientWs.on('close', (code, reason) => { if (geminiWs.readyState === WebSocket.OPEN) geminiWs.close(code, reason.toString()); });
    });
  } else {
    socket.destroy();
  }
});

process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});
