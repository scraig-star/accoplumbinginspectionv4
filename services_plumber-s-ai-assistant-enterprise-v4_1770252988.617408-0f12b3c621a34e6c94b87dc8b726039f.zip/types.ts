
export enum Severity {
  GRADE1 = '1',
  GRADE2 = '2',
  GRADE3 = '3',
  GRADE4 = '4',
  GRADE5 = '5'
}

export type VerificationStatus = 'pending' | 'confirmed' | 'trained' | 'rejected';

export type ActionType = 'GOOD_CONFIRMATION' | 'TRAIN_CORRECTION' | 'TRAIN_REJECTION';

export interface Occurrence {
  time: string;
  distance: string;
  frameIndex: number;
}

export interface Finding {
  id: string;
  issueNo: number;
  issueType: string;
  pacpCategory: string;
  pacpCode: string;
  severity: Severity;
  originalSeverity?: Severity;
  description: string;
  remediationMethod?: string;
  standardDescription?: string;
  occurrences: Occurrence[];
  startTime: string; 
  endTime: string;
  distance: string;
  frameIndex: number; 
  status?: VerificationStatus;
  _avgSeconds?: number;
}

export interface LearnedCorrection {
  originalType: string;
  originalSeverity: Severity;
  correctedType: string;
  correctedSeverity: Severity;
  actionType: ActionType;
  isRejection?: boolean;
  imageGcsUri?: string; 
  timestamp?: string;
  details?: string;
}

export interface ScopeTask {
  taskNumber: string;
  description: string;
  goal: string;
  location: string;
}

export interface ScopePhase {
  phaseName: string;
  tasks: ScopeTask[];
}

export interface InspectionSummary {
  conditionRating: 'Good' | 'Fair' | 'Poor' | 'Critical';
  nasscoGrade?: number; // 1-5 scale
  pipeMaterial: string;
  summaryText: string;
  detailedServiceSummary: string;
  sectionCondition: {
    section: string;
    condition: string;
    action: string;
  }[];
}

export interface InspectionData {
  customerName: string;
  address: string;
  technicianName: string;
  date: string;
  videoName: string;
  methodology: string;
  technicianAnalysis: string; 
  technicianNotes: string;    
  findings: Finding[];
  summary: InspectionSummary;
  scopeOfWork: ScopePhase[];
  totalFramesAnalyzed: number;
}

export interface FrameData {
  data: string; // Base64
  timestamp: number; // Seconds
  index: number;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'network';
  message: string;
  details?: any;
}
