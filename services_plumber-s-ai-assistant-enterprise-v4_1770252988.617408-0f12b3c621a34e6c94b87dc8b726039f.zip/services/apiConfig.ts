/**
 * CLOUD RUN PROXY CONFIGURATION
 * 
 * DYNAMIC BASE URL RESOLUTION
 * In production, the frontend and backend share the same domain.
 * Defaulting to an empty string ('') makes all API calls relative,
 * which automatically satisfies browser CORS security policies.
 */

const getBaseUrl = () => {
  if (typeof window === 'undefined') return '';
  let override = localStorage.getItem('ACCO_API_GATEWAY');
  
  if (override) {
    override = override.trim();
    if (!override.startsWith('http://') && !override.startsWith('https://')) {
      override = 'https://' + override;
    }
    return override.endsWith('/') ? override.slice(0, -1) : override;
  }
  
  // Default to relative path for unified deployment.
  // This allows the app to work seamlessly on Cloud Run without manual URL configuration.
  return ''; 
};

export const BASE_URL = getBaseUrl();

/**
 * GOOGLE CLOUD STORAGE BUCKET
 */
export const STORAGE_BUCKET_NAME = "acco-inspection-training-data";

export const isApiConfigured = () => true;

export const API_ENDPOINTS = {
  UPLOAD_IMAGE: '/api/v1/upload-image',
  SAVE_CORRECTION: '/api/v1/log-correction',
  HEALTH_CHECK: '/health',
  PING: '/api/v1/ping',
  DIAGNOSTIC: '/api/v1/diagnostic-test'
};