import { FrameData } from '../types.ts';
import { API_ENDPOINTS, STORAGE_BUCKET_NAME, isApiConfigured, BASE_URL } from './apiConfig.ts';
import { logRecorder } from './logService.ts';

/**
 * Uploads a frame to GCS via the Cloud Run Proxy.
 */
export const uploadFrameToGCS = async (base64Data: string, filename: string): Promise<string> => {
  if (!isApiConfigured()) {
    logRecorder.addLog('warning', "API URL not configured. Skipping GCS upload.");
    return ""; 
  }

  const endpoint = `${BASE_URL}${API_ENDPOINTS.UPLOAD_IMAGE}`;
  logRecorder.addLog('network', `POST ${endpoint}`);

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      mode: 'cors',
      headers: { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        image: base64Data,
        filename,
        bucket: STORAGE_BUCKET_NAME
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      logRecorder.addLog('error', `Proxy Storage Rejection (${response.status})`, { 
        status: response.status, 
        details: errorText.substring(0, 500) 
      });
      throw new Error(`Proxy Storage Rejection (${response.status})`);
    }
    
    const result = await response.json();
    return result.gcsUri;
  } catch (error: any) {
    logRecorder.addLog('error', "GCS Proxy Upload Exception", { message: error.message });
    throw error;
  }
};

/**
 * Extracts frames from a local video file using PARALLEL workers.
 */
export const extractFramesFromVideo = async (
  videoFile: File,
  intervalSeconds: number = 0.5, 
  maxFrames: number = 2000
): Promise<FrameData[]> => {
  const PARALLEL_WORKERS = 8;
  const fileURL = URL.createObjectURL(videoFile);

  try {
    const metaVideo = document.createElement('video');
    metaVideo.src = fileURL;
    await new Promise((resolve, reject) => {
      metaVideo.onloadedmetadata = resolve;
      metaVideo.onerror = () => reject(new Error("Failed to load video metadata"));
    });
    
    const duration = metaVideo.duration;
    if (isNaN(duration)) throw new Error("Invalid video duration");

    const targetTimestamps: number[] = [];
    for (let t = 0; t < duration && targetTimestamps.length < maxFrames; t += intervalSeconds) {
      targetTimestamps.push(t);
    }

    const segmentSize = Math.ceil(targetTimestamps.length / PARALLEL_WORKERS);
    const workerPromises = [];

    for (let i = 0; i < PARALLEL_WORKERS; i++) {
      const timestamps = targetTimestamps.slice(i * segmentSize, (i + 1) * segmentSize);
      if (timestamps.length === 0) continue;

      workerPromises.push((async () => {
        const video = document.createElement('video');
        video.src = fileURL;
        video.muted = true;
        video.playsInline = true;
        await new Promise(r => video.onloadedmetadata = r);
        
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        const TARGET_HEIGHT = 480;
        const scale = video.videoHeight > TARGET_HEIGHT ? TARGET_HEIGHT / video.videoHeight : 1;
        canvas.width = video.videoWidth * scale;
        canvas.height = video.videoHeight * scale;

        const results: FrameData[] = [];
        let currentIndex = 0;

        return new Promise<FrameData[]>((resolve) => {
          const seekAndCapture = () => {
            if (currentIndex >= timestamps.length) {
              video.src = ""; 
              resolve(results);
              return;
            }
            video.currentTime = timestamps[currentIndex];
          };

          video.onseeked = () => {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const base64Data = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
            results.push({
              data: base64Data,
              timestamp: timestamps[currentIndex],
              index: 0 
            });
            currentIndex++;
            seekAndCapture();
          };
          seekAndCapture();
        });
      })());
    }

    const allWorkerResults = await Promise.all(workerPromises);
    const flatFrames = allWorkerResults.flat().sort((a, b) => a.timestamp - b.timestamp);
    return flatFrames.map((f, i) => ({ ...f, index: i }));
  } finally {
    URL.revokeObjectURL(fileURL);
  }
};

export const formatTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};
