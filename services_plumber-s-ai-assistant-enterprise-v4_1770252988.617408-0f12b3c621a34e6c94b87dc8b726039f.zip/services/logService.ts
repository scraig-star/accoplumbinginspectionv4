
import { LogEntry } from '../types';

type LogListener = (logs: LogEntry[]) => void;

class LogRecorder {
  private logs: LogEntry[] = [];
  private listeners: LogListener[] = [];

  addLog(type: LogEntry['type'], message: string, details?: any) {
    const entry: LogEntry = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      type,
      message,
      details
    };
    this.logs.push(entry);
    this.notify();
    
    // Also log to browser console for immediate visibility
    const consoleMethod = type === 'error' ? 'error' : type === 'warning' ? 'warn' : 'log';
    console[consoleMethod](`[${type.toUpperCase()}] ${message}`, details || '');
  }

  getLogs() {
    return [...this.logs];
  }

  clear() {
    this.logs = [];
    this.notify();
  }

  subscribe(listener: LogListener) {
    this.listeners.push(listener);
    listener(this.logs);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.logs));
  }
}

export const logRecorder = new LogRecorder();
