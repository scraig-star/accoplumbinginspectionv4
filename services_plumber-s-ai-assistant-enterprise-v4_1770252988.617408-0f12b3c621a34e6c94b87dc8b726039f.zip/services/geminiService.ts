import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { FrameData, Finding, Severity, InspectionData, LearnedCorrection } from "../types.ts";
import { formatTime } from "./videoService.ts";
import { API_ENDPOINTS, isApiConfigured, BASE_URL } from "./apiConfig.ts";
import { logRecorder } from "./logService.ts";

const VISION_MODEL = "gemini-3-flash-preview"; 
const SYNTHESIS_MODEL = "gemini-3-flash-preview"; 

const BATCH_SIZE = 120;              
const OVERLAP = 0;                   
const CONCURRENCY_LIMIT = 25;        
const DETERMINISTIC_SEED = 42; 

const LOCAL_DEDUPE_THRESHOLD_SECONDS = 8;

const STORAGE_KEY = 'ACCO_LEARNED_CORRECTIONS';

function selectKeyFrames(frames: FrameData[], targetCount: number = 500): FrameData[] {
  if (frames.length <= targetCount) return frames;
  const step = frames.length / targetCount;
  const selected: FrameData[] = [];
  for (let i = 0; i < targetCount; i++) {
    const index = Math.floor(i * step);
    selected.push(frames[index]);
  }
  return selected;
}

class CircuitBreaker {
  private failures = 0;
  private readonly threshold = 5;
  private readonly resetTime = 60000;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  private lastFailureTime = 0;
  private successCount = 0;

  async execute<T>(fn: () => Promise<T>, label: string): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime > this.resetTime) {
        logRecorder.addLog('info', `Circuit breaker transitioning to HALF_OPEN for ${label}`);
        this.state = 'HALF_OPEN';
        this.successCount = 0;
      } else {
        const waitTime = Math.round((this.resetTime - (Date.now() - this.lastFailureTime)) / 1000);
        throw new Error(`Circuit breaker OPEN for ${label}. Retry in ${waitTime}s`);
      }
    }

    try {
      const result = await fn();
      if (this.state === 'HALF_OPEN') {
        this.successCount++;
        if (this.successCount >= 3) {
          logRecorder.addLog('success', `Circuit breaker CLOSED for ${label}`);
          this.state = 'CLOSED';
          this.failures = 0;
        }
      }
      return result;
    } catch (error: any) {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.threshold) {
        logRecorder.addLog('error', `Circuit breaker OPEN for ${label} after ${this.failures} failures`);
        this.state = 'OPEN';
      }
      throw error;
    }
  }

  reset() {
    this.state = 'CLOSED';
    this.failures = 0;
    this.successCount = 0;
  }
}

const apiCircuitBreaker = new CircuitBreaker();

export const getLearnedCorrections = (): LearnedCorrection[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveLearnedCorrection = async (correction: LearnedCorrection) => {
  const existing = getLearnedCorrections();
  if (!existing.some(c => c.correctedType === correction.correctedType && c.originalType === correction.originalType)) {
    existing.push(correction);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(existing.slice(-100))); 
  }

  if (!isApiConfigured()) {
    logRecorder.addLog('warning', "API not configured. Skipping cloud sync.");
    return true;
  }

  const endpoint = `${BASE_URL}${API_ENDPOINTS.SAVE_CORRECTION}`;
  logRecorder.addLog('network', `POST ${endpoint} (Correction: ${correction.isRejection ? 'REJECTION' : correction.correctedType})`);

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        ...correction,
        status: 'pending_jsonl_export',
        source: 'ACCO_INSPECTION_TOOL_V3'
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      logRecorder.addLog('error', `Cloud sync failed (${response.status})`, { details: errorText });
      const err: any = new Error(`Cloud sync failed: ${response.status}`);
      err.status = response.status;
      err.details = errorText;
      throw err;
    }

    logRecorder.addLog('success', "Correction synced to cloud");
    return true;
  } catch (error: any) {
    logRecorder.addLog('error', "Cloud sync exception", { message: error.message });
    throw error;
  }
};

async function withRetry<T>(fn: () => Promise<T>, label: string, retries = 3, delay = 1000): Promise<T> {
  try {
    return await apiCircuitBreaker.execute(fn, label);
  } catch (error: any) {
    if (retries <= 0) {
      logRecorder.addLog('error', `${label} failed after all retries`, { error: error.message });
      throw error;
    }
    const backoffDelay = delay * Math.pow(2, 3 - retries);
    logRecorder.addLog('warning', `${label} failed, retrying in ${backoffDelay}ms... (${retries} left)`);
    await new Promise(resolve => setTimeout(resolve, backoffDelay));
    return withRetry(fn, label, retries - 1, delay);
  }
}

function extractJson(text: string): any {
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    try {
      const patterns = [/```json\s*([\s\S]*?)\s*```/, /```\s*([\s\S]*?)\s*```/, /\{[\s\S]*\}/];
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match) {
          const cleaned = match[1] || match[0];
          try { return JSON.parse(cleaned); } catch {}
        }
      }
      return null;
    } catch (e) { return null; }
  }
}

function localDeduplicateRawFindings(findings: any[]): any[] {
  if (findings.length === 0) return [];
  const sorted = [...findings].sort((a, b) => a.seconds - b.seconds);
  const deduplicated: any[] = [];
  for (const f of sorted) {
    const last = deduplicated[deduplicated.length - 1];
    if (last && last.pacpCode === f.pacpCode && Math.abs(f.seconds - last.seconds) < LOCAL_DEDUPE_THRESHOLD_SECONDS) {
      if (parseInt(f.severity) > parseInt(last.severity)) last.severity = f.severity;
      last.mergedIds.push(f.rawId);
      if (f.distance && f.distance !== last.distance) last.distanceRange = `${last.distance} - ${f.distance}`;
    } else {
      deduplicated.push({ ...f, mergedIds: [f.rawId], distanceRange: f.distance });
    }
  }
  return deduplicated;
}

const batchSchema = {
  type: Type.OBJECT,
  properties: {
    findings: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          pacpCategory: { type: Type.STRING, enum: ["Pipe Wall Damage", "Roots & Blockages", "Fittings & Joints", "General Observations"] },
          pacpCode: { type: Type.STRING },
          issueType: { type: Type.STRING },
          severity: { type: Type.STRING, enum: ["1", "2", "3", "4", "5"] },
          description: { type: Type.STRING },
          standardDescription: { type: Type.STRING },
          distance: { type: Type.STRING },
          batchFrameIndex: { type: Type.INTEGER }
        },
        required: ["pacpCategory", "pacpCode", "issueType", "severity", "description", "standardDescription", "distance", "batchFrameIndex"]
      }
    }
  },
  required: ["findings"]
};

const fullSynthesisSchema = {
  type: Type.OBJECT,
  properties: {
    pipeMaterial: { type: Type.STRING },
    summary: {
      type: Type.OBJECT,
      properties: {
        conditionRating: { type: Type.STRING, enum: ["Good", "Fair", "Poor", "Critical"] },
        nasscoGrade: { type: Type.INTEGER },
        summaryText: { type: Type.STRING },
        detailedServiceSummary: { type: Type.STRING },
        sectionCondition: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: { section: { type: Type.STRING }, condition: { type: Type.STRING }, action: { type: Type.STRING } }
          }
        }
      },
      required: ["conditionRating", "nasscoGrade", "summaryText", "detailedServiceSummary", "sectionCondition"]
    },
    videoInspectionNotes: { type: Type.STRING },
    scopeOfWork: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: { phaseName: { type: Type.STRING }, tasks: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { taskNumber: { type: Type.STRING }, description: { type: Type.STRING }, goal: { type: Type.STRING }, location: { type: Type.STRING } } } } }
      }
    },
    consolidatedFindingIds: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: { issueType: { type: Type.STRING }, remediationMethod: { type: Type.STRING }, originalFindingIds: { type: Type.ARRAY, items: { type: Type.STRING } } },
        required: ["issueType", "remediationMethod", "originalFindingIds"]
      }
    }
  },
  required: ["pipeMaterial", "summary", "videoInspectionNotes", "scopeOfWork", "consolidatedFindingIds"]
};

async function analyzeFrameBatch(frames: FrameData[], globalStartIndex: number, corrections: LearnedCorrection[], guidance?: string): Promise<any[]> {
  // FIXED: Use backend proxy instead of direct API key
  const ai = new GoogleGenAI({ 
    apiKey: 'dummy-key-proxied-by-backend',
    baseUrl: '/api-proxy'
  });
  
  const parts = frames.map(f => ({ inlineData: { mimeType: "image/jpeg", data: f.data } }));
  const learnedContext = corrections.length > 0 ? `\nLEARNED CORRECTIONS:\n${corrections.slice(-20).map(c => `- "${c.originalType}" → "${c.correctedType}" (Grade ${c.correctedSeverity})`).join('\n')}` : "";
  const guidancePrompt = guidance ? `\n\nSPECIAL FOCUS: Prioritize detection of "${guidance}". Include even minor occurrences.` : "";
  const prompt = `SEWER INSPECTION ANALYSIS - BATCH ${Math.floor(globalStartIndex / BATCH_SIZE) + 1}\n${learnedContext}${guidancePrompt}\nREQUIREMENTS:\n1. Identify ALL defects visible in these ${frames.length} frames\n2. For standardDescription: ALWAYS provide IPC reference first, then UPC\nFormat: "IPC [Section]: [Standard] | UPC [Section]: [Standard]"\n3. Severity scale: 1=Normal, 2=Minor, 3=Fair, 4=Poor, 5=Critical\nReturn findings in strict JSON format.`;
  
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: VISION_MODEL,
    contents: { parts: [...parts, { text: prompt }] },
    config: { responseMimeType: "application/json", responseSchema: batchSchema as any, temperature: 0, seed: DETERMINISTIC_SEED }
  });

  try {
    const parsed = extractJson(response.text || "{}");
    if (!parsed || !parsed.findings) return [];
    return (parsed.findings || []).map((f: any) => {
      const localIndex = Math.min(Math.max(0, f.batchFrameIndex || 0), frames.length - 1);
      const targetFrame = frames[localIndex];
      return { ...f, time: formatTime(targetFrame.timestamp), seconds: targetFrame.timestamp, frameIndex: targetFrame.index, rawId: `raw-${globalStartIndex}-${localIndex}-${Math.random().toString(36).substr(2, 5)}` };
    });
  } catch (err) { return []; }
}

export const processVideoInBatches = async (allFrames: FrameData[], onProgress: (msg: string, pct: number) => void, guidance?: string): Promise<Partial<InspectionData>> => {
  if (!allFrames || allFrames.length === 0) throw new Error("No frames provided for analysis");
  const frames = selectKeyFrames(allFrames, 500);
  const startTime = Date.now();
  apiCircuitBreaker.reset();
  const corrections = getLearnedCorrections();
  let allRaw: any[] = [];
  const tasks = [];
  for (let i = 0; i < frames.length; i += BATCH_SIZE) {
    tasks.push({ frames: frames.slice(i, Math.min(i + BATCH_SIZE, frames.length)), startIndex: i });
  }

  const workerPool = async (taskQueue: any[]) => {
    const totalBatches = taskQueue.length;
    let completed = 0;
    const workers = Array(Math.min(CONCURRENCY_LIMIT, totalBatches)).fill(null).map(async () => {
      while (taskQueue.length > 0) {
        const task = taskQueue.shift();
        if (!task) break;
        try {
          const res = await withRetry(() => analyzeFrameBatch(task.frames, task.startIndex, corrections, guidance), `Batch-${task.startIndex}`, 3, 1000);
          allRaw.push(...res);
        } catch (e) {} finally {
          completed++;
          onProgress(`Analyzing frames... (${completed}/${totalBatches} batches)`, Math.min(10 + (completed / totalBatches) * 70, 80));
        }
      }
    });
    await Promise.all(workers);
  };

  await workerPool([...tasks]);
  if (allRaw.length === 0) throw new Error("No findings detected in video. Pipeline empty.");
  onProgress("Consolidating findings...", 82);
  const cleanedRaw = localDeduplicateRawFindings(allRaw);
  const rawFindingsMap = new Map(allRaw.map(f => [f.rawId, f]));
  onProgress("Generating final report...", 85);
  const slimData = cleanedRaw.map(f => ({ id: f.rawId, type: f.issueType, sev: f.severity, code: f.pacpCode, dist: f.distanceRange || f.distance, time: f.time, mergedIds: f.mergedIds, desc: f.description.substring(0, 100) }));
  
  const synthesisPrompt = `COMPREHENSIVE REPORT SYNTHESIS\n${guidance ? `\nCONTEXT: Targeted rescan for "${guidance}"` : ''}\nDATASET: ${JSON.stringify(slimData)}\nINSTRUCTIONS:\n1. CONSOLIDATE duplicate findings (same PACP code, nearby locations)\n2. Assign specific remediation recommendations\n3. Generate Grade 1-5 overall assessment\n4. In consolidatedFindingIds, include ALL originalFindingIds AND mergedIds\n5. EXCLUDE any findings related to the operation of the inspection equipment (e.g., 'camera malfunction', 'lens flare', 'tractor unit obstruction', 'signal drop'). Focus strictly on structural and operational pipe defects.\nOutput valid JSON only.`;
  
  // FIXED: Use backend proxy instead of direct API key
  const ai = new GoogleGenAI({ 
    apiKey: 'dummy-key-proxied-by-backend',
    baseUrl: '/api-proxy'
  });
  
  const synthesis: GenerateContentResponse = await withRetry(() => ai.models.generateContent({ model: SYNTHESIS_MODEL, contents: synthesisPrompt, config: { responseMimeType: "application/json", responseSchema: fullSynthesisSchema as any, temperature: 0, seed: DETERMINISTIC_SEED } }), "Report-Synthesis", 3, 2000);
  onProgress("Finalizing report...", 95);
  const tech = extractJson(synthesis.text || "{}");
  if (!tech || !tech.summary) throw new Error("Synthesis failed to produce valid report structure");

  let consolidatedFindings: Finding[] = (tech.consolidatedFindingIds || []).map((group: any, i: number) => {
    const groupFindings = (group.originalFindingIds || []).map((id: string) => rawFindingsMap.get(id)).filter(Boolean);
    if (groupFindings.length === 0) return null;
    const primary = groupFindings.sort((a, b) => parseInt(b.severity) - parseInt(a.severity))[0];
    const occurrences = groupFindings.sort((a, b) => a.frameIndex - b.frameIndex).map((f: any) => ({ time: f.time, distance: f.distance, frameIndex: f.frameIndex, seconds: f.seconds }));
    return {
      id: `f-${Date.now()}-${i}`, issueNo: i + 1, issueType: group.issueType || primary.issueType, pacpCategory: primary.pacpCategory, pacpCode: primary.pacpCode,
      severity: (group.severity || primary.severity) as Severity, originalSeverity: primary.severity as Severity, description: primary.description,
      remediationMethod: group.remediationMethod || primary.remediationMethod || "Further inspection required", standardDescription: primary.standardDescription,
      occurrences: occurrences, startTime: occurrences[0]?.time || "00:00", endTime: occurrences[occurrences.length - 1]?.time || "00:00",
      distance: occurrences[0]?.distance || "N/A", frameIndex: occurrences[0]?.frameIndex || 0, status: 'pending',
      _avgSeconds: occurrences.reduce((acc, curr) => acc + curr.seconds, 0) / occurrences.length
    };
  }).filter(Boolean);

  const finalFindings: Finding[] = consolidatedFindings.sort((a: any, b: any) => a._avgSeconds - b._avgSeconds).map((f, idx) => ({ ...f, issueNo: idx + 1 }));
  onProgress("Complete", 100);
  return { ...tech, technicianNotes: tech.videoInspectionNotes || "", findings: finalFindings } as any;
};
