
/**
 * DEPRECATED
 * This file has been removed in favor of the Cloud Run Proxy architecture.
 * See server.js and apiConfig.ts for backend connection logic.
 */
export {};
