/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

const { Firestore } = require('@google-cloud/firestore');
const { Storage } = require('@google-cloud/storage');

const firestore = new Firestore();
const storage = new Storage();

/**
 * HTTP Cloud Function to export Firestore corrections to GCS in JSONL format.
 */
exports.exportFirestoreToJSONL = async (req, res) => {
  try {
    const bucketName = process.env.GCS_BUCKET_NAME || 'acco-inspection-training-data';
    const collectionName = 'corrections';

    console.log(`[EXPORT] Starting batch export from ${collectionName}...`);

    const snapshot = await firestore.collection(collectionName)
      .where('status', '==', 'pending_jsonl_export')
      .get();

    if (snapshot.empty) {
      console.log('[EXPORT] No records found for processing.');
      return res.status(200).json({ success: true, message: "Dataset up to date." });
    }

    let jsonlContent = '';
    const batch = firestore.batch();

    snapshot.forEach(doc => {
      const data = doc.data();
      
      // Fine-tuning format for Gemini 1.5/2.5 series
      const trainingRecord = {
        contents: [
          {
            role: 'user',
            parts: [
              { text: `Pipe defect analysis. Original call: ${data.originalType}` },
              { fileData: { fileUri: data.imageGcsUri, mimeType: 'image/jpeg' } }
            ]
          },
          {
            role: 'model',
            parts: [
              { text: `Defect: ${data.correctedType}, Grade: ${data.correctedSeverity}.` }
            ]
          }
        ]
      };
      
      jsonlContent += JSON.stringify(trainingRecord) + '\n';
      batch.update(doc.ref, { 
        status: 'exported_to_jsonl', 
        exportTimestamp: Firestore.FieldValue.serverTimestamp() 
      });
    });

    const filename = `datasets/acco_tuning_v2_${Date.now()}.jsonl`;
    const file = storage.bucket(bucketName).file(filename);

    await file.save(jsonlContent, { 
      metadata: { contentType: 'application/jsonl' }
    });
    
    await batch.commit();

    console.log(`[EXPORT SUCCESS] Created ${filename}`);

    res.status(200).json({ 
      success: true, 
      count: snapshot.size,
      gcsUri: `gs://${bucketName}/${filename}`
    });
  } catch (error) {
    console.error("[EXPORT ERROR]", error);
    res.status(500).json({ error: error.message });
  }
};
