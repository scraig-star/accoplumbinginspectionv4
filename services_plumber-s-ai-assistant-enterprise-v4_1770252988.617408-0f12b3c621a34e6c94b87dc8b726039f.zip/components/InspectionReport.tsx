import React, { useState, useMemo, useEffect } from 'react';
import { InspectionData, FrameData, Severity, Finding, LogEntry, VerificationStatus, Occurrence, ActionType, LearnedCorrection } from '../types.ts';
import { saveLearnedCorrection, processVideoInBatches } from '../services/geminiService.ts';
import { uploadFrameToGCS } from '../services/videoService.ts';
import { logRecorder } from '../services/logService.ts';
import { 
  ArrowLeft, Edit3, FileOutput, FileText, Activity, Wrench, ShieldCheck, XCircle, Smartphone, CheckCircle2, Loader2, Terminal, Copy, Check, Trash2, Zap, ClipboardList, X, Layers
} from 'lucide-react';
import { BASE_URL } from '../services/apiConfig.ts';

interface Props {
  data: InspectionData;
  frames: FrameData[];
  showProposal?: boolean;
  onEnableProposal?: () => void;
  onBack: () => void;
  onBackToOptions?: () => void;
  onToggleArchitecture: () => void;
}

const ACCO_NEW_LOGO = "https://raw.githubusercontent.com/scraig-star/acco-assetsseangoogleaitest/9f3443041c44a0f155c2b23b596de1e5e7fc0258/ACCO%20Logo.png";

// Keywords to filter out non-structural/equipment-related noise
const EXCLUDED_KEYWORDS = ['malfunction', 'camera error', 'tractor', 'operator error', 'glitch', 'signal drop', 'lens flare'];

const InspectionReport: React.FC<Props> = ({ data, frames, showProposal, onBack, onToggleArchitecture }) => {
  const [localFindings, setLocalFindings] = useState<Finding[]>(data.findings);
  const [editingFindingId, setEditingFindingId] = useState<string | null>(null);
  const [isSyncingId, setIsSyncingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{type: string, severity: Severity}>({type: '', severity: Severity.GRADE1});
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showTrace, setShowTrace] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const [rescanGuidance, setRescanGuidance] = useState('');
  const [isRescanning, setIsRescanning] = useState(false);
  const [rescanProgress, setRescanProgress] = useState(0);

  useEffect(() => {
    return logRecorder.subscribe(setLogs);
  }, []);

  const getSeverityStyles = (severity: Severity) => {
    switch (severity) {
      case Severity.GRADE5: return { bg: '#D31245', text: 'white', label: 'GRADE 5 - CRITICAL' };
      case Severity.GRADE4: return { bg: '#E11D48', text: 'white', label: 'GRADE 4 - POOR' };
      case Severity.GRADE3: return { bg: '#F59E0B', text: 'black', label: 'GRADE 3 - FAIR' };
      case Severity.GRADE2: return { bg: '#84CC16', text: 'white', label: 'GRADE 2 - MINOR' };
      case Severity.GRADE1:
      default: return { bg: '#22C55E', text: 'white', label: 'GRADE 1 - NORMAL' };
    }
  };

  const getRatingColor = (rating: string | undefined) => {
    switch (rating) {
      case 'Critical':
      case 'Poor': return '#D31245';
      case 'Fair': return '#F59E0B';
      case 'Good': return '#22C55E';
      default: return '#084C7C';
    }
  };

  const getFrameImage = (index: number) => {
    const frame = frames[index];
    return frame ? `data:image/jpeg;base64,${frame.data}` : '';
  };

  const startEdit = (finding: Finding) => {
    setEditingFindingId(finding.id);
    setEditForm({ type: finding.issueType, severity: finding.severity });
  };

  const displayRichError = (title: string, error: any) => {
    console.error(`[PIPELINE FAILURE] ${title}:`, error);
    const detailedMessage = `
--- ${title} FAILURE ---
Error: ${error.message || 'Unknown error'}
Status: ${error.status || 'N/A'}
Endpoint: ${error.url || 'Internal'}
Details: ${error.details || 'Consult developer console (F12) for stack trace.'}
------------------------
    `.trim();
    alert(detailedMessage);
  };

  const copyLogs = () => {
    const logText = logs.map(l => `[${l.timestamp}] [${l.type.toUpperCase()}] ${l.message} ${l.details ? JSON.stringify(l.details) : ''}`).join('\n');
    navigator.clipboard.writeText(logText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const removeOccurrence = async (findingId: string, frameIndex: number) => {
    const finding = localFindings.find(f => f.id === findingId);
    if (!finding) return;

    logRecorder.addLog('info', `Individual frame rejection: Removing frame ${frameIndex} from Finding ${findingId}`);

    try {
      const frameData = frames[frameIndex];
      if (frameData) {
        const timestamp = Date.now();
        const filename = `Training_Rejection_${timestamp}_idx${frameIndex}.jpg`;
        const gcsUri = await uploadFrameToGCS(frameData.data, filename);
        
        await saveLearnedCorrection({
          originalType: finding.issueType,
          originalSeverity: finding.originalSeverity || finding.severity,
          correctedType: "FRAME_REJECTION",
          correctedSeverity: Severity.GRADE1,
          actionType: 'TRAIN_REJECTION',
          isRejection: true,
          imageGcsUri: gcsUri,
          timestamp: new Date().toISOString(),
          details: `Train AI - Rejection (Individual Frame)`
        });
      }
    } catch (e) {
      console.warn("Could not log individual frame rejection to AI pipeline", e);
    }

    setLocalFindings(prev => prev.map(f => {
      if (f.id === findingId) {
        const newOccs = f.occurrences.filter(occ => occ.frameIndex !== frameIndex);
        if (newOccs.length === 0) {
          return { ...f, status: 'rejected' };
        }
        let newPrimaryIndex = f.frameIndex;
        if (f.frameIndex === frameIndex) {
          newPrimaryIndex = newOccs[0].frameIndex;
        }
        return { ...f, occurrences: newOccs, frameIndex: newPrimaryIndex };
      }
      return f;
    }));
  };

  const saveCorrection = async (id: string) => {
    const original = localFindings.find(f => f.id === id);
    if (!original) return;
    
    setIsSyncingId(id);
    const isActuallyCorrected = editForm.type !== original.issueType || editForm.severity !== original.severity;
    const actionLabel = isActuallyCorrected ? "Correction" : "TrainAI_Confirmation";
    const detailLabel = isActuallyCorrected ? "Train AI - Correction" : "Train AI - Confirmation";
    const actionType: ActionType = isActuallyCorrected ? 'TRAIN_CORRECTION' : 'GOOD_CONFIRMATION';

    logRecorder.addLog('info', `Batch Train AI initiated for Finding ${id} (${detailLabel})`);

    try {
      for (const occ of original.occurrences) {
        const frameData = frames[occ.frameIndex];
        if (frameData) {
          const timestamp = Date.now();
          const filename = `Training_${actionLabel}_${timestamp}_${id}_idx${occ.frameIndex}.jpg`;
          const gcsUri = await uploadFrameToGCS(frameData.data, filename);

          await saveLearnedCorrection({ 
            originalType: original.issueType,
            originalSeverity: original.originalSeverity || original.severity,
            correctedType: editForm.type, 
            correctedSeverity: editForm.severity,
            actionType: actionType,
            imageGcsUri: gcsUri,
            timestamp: new Date().toISOString(),
            details: detailLabel
          });
        }
      }

      setLocalFindings(prev => prev.map(f => f.id === id ? { 
        ...f, 
        issueType: editForm.type, 
        severity: editForm.severity, 
        status: 'trained' 
      } : f));
      
      setEditingFindingId(null);
      logRecorder.addLog('success', `Trained AI on all ${original.occurrences.length} images in finding group ${id}.`);
    } catch (error: any) {
      displayRichError("TRAIN AI", error);
    } finally {
      setIsSyncingId(null);
    }
  };

  const confirmFinding = async (id: string) => {
    const finding = localFindings.find(f => f.id === id);
    if (!finding) return;

    setIsSyncingId(id);
    logRecorder.addLog('info', `Batch confirmation initiated for Finding ${id}`);
    
    try {
      for (const occ of finding.occurrences) {
        const frameData = frames[occ.frameIndex];
        if (frameData) {
          const timestamp = Date.now();
          const filename = `Training_Confirmation_${timestamp}_${id}_idx${occ.frameIndex}.jpg`;
          const gcsUri = await uploadFrameToGCS(frameData.data, filename);

          await saveLearnedCorrection({
            originalType: finding.issueType,
            originalSeverity: finding.originalSeverity || finding.severity,
            correctedType: finding.issueType,
            correctedSeverity: finding.severity,
            actionType: 'GOOD_CONFIRMATION',
            imageGcsUri: gcsUri,
            timestamp: new Date().toISOString(),
            details: "Good Confirmation"
          });
        }
      }

      setLocalFindings(prev => prev.map(f => {
        if (f.id === id) return { ...f, status: 'confirmed' as VerificationStatus };
        return f;
      }));
      logRecorder.addLog('success', `Confirmed all ${finding.occurrences.length} images in finding group ${id}.`);
    } catch (error: any) {
      displayRichError("CONFIRMATION", error);
    } finally {
      setIsSyncingId(null);
    }
  };

  const rejectFinding = async (id: string) => {
    const finding = localFindings.find(f => f.id === id);
    if (!finding) return;

    setIsSyncingId(id);
    logRecorder.addLog('warning', `Batch rejection initiated for Finding ${id}`);

    try {
      for (const occ of finding.occurrences) {
        const frameData = frames[occ.frameIndex];
        if (frameData) {
          const timestamp = Date.now();
          const filename = `Training_Rejection_${timestamp}_${id}_idx${occ.frameIndex}.jpg`;
          const gcsUri = await uploadFrameToGCS(frameData.data, filename);

          await saveLearnedCorrection({
            originalType: finding.issueType,
            originalSeverity: finding.originalSeverity || finding.severity,
            correctedType: "NULL_REJECTION",
            correctedSeverity: Severity.GRADE1,
            actionType: 'TRAIN_REJECTION',
            isRejection: true,
            imageGcsUri: gcsUri,
            timestamp: new Date().toISOString(),
            details: `Train AI - Rejection`
          });
        }
      }

      setLocalFindings(prev => prev.map(f => {
        if (f.id === id) return { ...f, status: 'rejected' as VerificationStatus };
        return f;
      }));
      logRecorder.addLog('success', `Rejected all ${finding.occurrences.length} images in finding group ${id}.`);
    } catch (error: any) {
      displayRichError("REJECTION", error);
    } finally {
      setIsSyncingId(null);
    }
  };

  const handleTargetedRescan = async () => {
    if (!rescanGuidance.trim()) return;
    setIsRescanning(true);
    setRescanProgress(0);
    try {
      const result = await processVideoInBatches(frames, (msg, pct) => setRescanProgress(pct), rescanGuidance);
      if (result.findings && result.findings.length > 0) {
        const newFindings = result.findings as Finding[];
        const merged = [...localFindings];
        newFindings.forEach(nf => {
          const isDuplicate = merged.some(ef => ef.pacpCode === nf.pacpCode && Math.abs((ef._avgSeconds || 0) - (nf._avgSeconds || 0)) < 20);
          if (!isDuplicate) merged.push(nf);
        });
        const reSorted = merged.sort((a, b) => (a._avgSeconds || 0) - (b._avgSeconds || 0)).map((f, i) => ({ ...f, issueNo: i + 1 }));
        setLocalFindings(reSorted);
        alert(`Rescan complete. Added ${reSorted.length - localFindings.length} new events.`);
      } else {
        alert("Rescan complete. No additional defects were identified.");
      }
      setRescanGuidance('');
    } catch (e: any) {
      displayRichError("TARGETED RESCAN", e);
    } finally {
      setIsRescanning(false);
    }
  };

  // Secondary guardrail: Filter out equipment-related noise
  const displayedFindings = useMemo(() => {
    return [...localFindings]
      .filter(f => !EXCLUDED_KEYWORDS.some(kw => 
        f.issueType.toLowerCase().includes(kw) || 
        f.description.toLowerCase().includes(kw)
      ))
      .sort((a, b) => parseInt(b.severity) - parseInt(a.severity));
  }, [localFindings]);

  // Secondary guardrail: Filter out equipment-related noise for export
  const exportedFindings = useMemo(() => {
    return localFindings
      .filter(f => f.status !== 'rejected')
      .filter(f => !EXCLUDED_KEYWORDS.some(kw => 
        f.issueType.toLowerCase().includes(kw) || 
        f.description.toLowerCase().includes(kw)
      ))
      .sort((a, b) => parseInt(b.severity) - parseInt(a.severity));
  }, [localFindings]);

  const handleDownloadWord = () => {
    const header = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><meta charset="utf-8"><style>
          @page { size: 8.5in 11.0in; margin: 0.5in; }
          body { font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.5; color: #1e293b; }
          .report-label { font-size: 16pt; font-weight: 800; text-transform: uppercase; color: #084C7C; text-align: right; }
          .blue-line { border-top: 2.5pt solid #084C7C; margin: 10pt 0; }
          .section-header { font-size: 10.5pt; font-weight: 900; color: #084C7C; text-transform: uppercase; margin-top: 25pt; margin-bottom: 12pt; background: #f1f5f9; padding: 8pt 12pt; border-radius: 1pt; }
          .finding-card { page-break-inside: avoid; margin-bottom: 40pt; border-bottom: 0.5pt solid #cbd5e1; padding-bottom: 25pt; }
          .pill-blue { background-color: #084C7C; color: white; padding: 3pt 8pt; font-size: 7.5pt; font-weight: 800; text-transform: uppercase; border-radius: 1pt; display: inline-block; margin-right: 5pt; }
          .pill-sev { padding: 3pt 8pt; font-size: 7.5pt; font-weight: 800; text-transform: uppercase; border-radius: 1pt; display: inline-block; }
          .priority-table { width: 100%; border-collapse: collapse; margin-top: 25pt; }
          .priority-table th { background: #084C7C; color: white; padding: 12pt; font-size: 8pt; text-transform: uppercase; text-align: left; letter-spacing: 0.05em; }
          .priority-table td { padding: 12pt; border-bottom: 1pt solid #f1f5f9; font-size: 9.5pt; vertical-align: middle; }
        </style></head><body>`;

    let content = `
      <table width="100%"><tr><td><img src="${ACCO_NEW_LOGO}" width="110"></td><td class="report-label">TECHNICAL ANALYSIS REPORT</td></tr></table>
      <div class="blue-line"></div>
      
      <div class="section-header">Executive Summary</div>
      <p style="font-weight:bold; color:${getRatingColor(data.summary.conditionRating)};">${data.summary.conditionRating} | Grade ${data.summary.nasscoGrade}/5</p>
      <div style="font-size: 11pt; line-height: 1.6; margin-bottom: 10pt;">${data.summary.summaryText}</div>
      <div style="font-size: 10pt; line-height: 1.5; color: #475569; padding: 10pt; background: #f8fafc;">${data.summary.detailedServiceSummary}</div>

      <div class="section-header">Technician Inspection Notes</div>
      <div style="font-size: 10pt; line-height: 1.6;">${data.technicianNotes}</div>

      <div class="section-header">Detailed Findings</div>
      ${exportedFindings.map(f => {
        const s = getSeverityStyles(f.severity);
        return `<div class="finding-card">
          <div style="margin-bottom:10pt;">
            <span class="pill-blue">${f.pacpCode}</span>
            <span class="pill-sev" style="background:${s.bg}; color:${s.text};">${s.label}</span>
          </div>
          <h4 style="font-size:14pt; color:#084C7C; margin-top:5pt; text-transform:uppercase;">${f.issueType}</h4>
          <p>${f.description}</p>
          <div style="margin-top:10pt; padding:10pt; background:#f0f7ff; border-left:3pt solid #084C7C;">
            <div style="font-size:8pt; font-weight:900; color:#084C7C; text-transform:uppercase; margin-bottom:4pt;">Recommendation</div>
            <div style="font-size:11pt; font-weight:700; color:#084C7C;">${f.remediationMethod}</div>
          </div>
          <table width="100%" style="margin-top:15pt;"><tr>${f.occurrences.slice(0, 4).map(occ => `<td width="25%"><img src="${getFrameImage(occ.frameIndex)}" width="150" /><div style="font-size:7pt;text-align:center;">DIST: ${occ.distance}</div></td>`).join('')}</tr></table>
        </div>`}).join('')}`;

    if (showProposal) {
      content += `<br clear=all style='page-break-before:always'><h2 style="text-align:center; color:#084C7C;">REMEDIATION PROPOSAL</h2>
      <table class="priority-table" width="100%">
        <thead><tr><th>Severity</th><th>Description</th><th>Remediation</th><th align="right">Cost</th></tr></thead>
        <tbody>
          ${exportedFindings.map(f => {
            const s = getSeverityStyles(f.severity);
            return `<tr>
              <td><span style="background:${s.bg};color:${s.text};padding:3pt 6pt;font-size:8pt;font-weight:800;border-radius:1pt;">${s.label}</span></td>
              <td><div style="font-weight:800;color:#084C7C;">${f.issueType}</div></td>
              <td>${f.remediationMethod}</td>
              <td align="right">$ ________.00</td>
            </tr>`
          }).join('')}
        </tbody>
      </table>
      
      <div style="margin-top: 40pt; border: 1pt solid #cbd5e1; padding: 25pt; background: #fafafa;">
        <div style="font-weight:900; color:#084C7C; text-transform:uppercase; font-size:11pt; border-bottom: 0.5pt solid #cbd5e1; padding-bottom: 5pt; margin-bottom: 15pt;">Project Authorization & Acceptance</div>
        <table width="100%">
          <tr>
            <td width="60%" style="border-bottom: 0.5pt solid black; height: 30pt;"><div style="font-size: 8pt; font-weight: bold; color: #64748b; text-transform: uppercase; margin-top: 25pt;">Customer Acceptance Signature</div></td>
            <td width="5%"></td>
            <td width="35%" style="border-bottom: 0.5pt solid black; height: 30pt;"><div style="font-size: 8pt; font-weight: bold; color: #64748b; text-transform: uppercase; margin-top: 25pt;">Date</div></td>
          </tr>
          <tr>
            <td width="60%" style="border-bottom: 0.5pt solid black; height: 30pt;"><div style="font-size: 8pt; font-weight: bold; color: #64748b; text-transform: uppercase; margin-top: 25pt;">Print Name</div></td>
            <td width="5%"></td>
            <td width="35%" style="border-bottom: 0.5pt solid black; height: 30pt;"><div style="font-size: 8pt; font-weight: bold; color: #64748b; text-transform: uppercase; margin-top: 25pt;">Total Investment</div></td>
          </tr>
        </table>
      </div>`;
    }

    const blob = new Blob(['\ufeff', header + content + "</body></html>"], { type: 'application/msword' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `ACCO_Report_${data.customerName.replace(/\s+/g, '_')}.doc`;
    link.click();
  };

  return (
    <div className="bg-slate-50 min-h-screen font-sans text-slate-900 pb-20 relative">
      <div className="no-print bg-white border-b border-slate-200 p-4 sticky top-0 z-50 shadow-sm">
        <div className="max-w-6xl mx-auto flex justify-between items-center px-4">
          <button onClick={onBack} className="flex items-center text-slate-500 hover:text-[#084C7C] font-bold text-[10px] uppercase tracking-widest transition-colors"><ArrowLeft className="h-4 w-4 mr-2" /> Back</button>
          <div className="flex gap-3">
            <button onClick={handleDownloadWord} className="bg-[#084C7C] text-white px-6 py-2.5 rounded shadow-sm text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-slate-800 transition-all"><FileOutput className="w-4 h-4" /> Word Document</button>
            <button onClick={() => window.print()} className="bg-[#D31245] text-white px-6 py-2.5 rounded shadow-sm text-[10px] font-black uppercase tracking-widest transition-all hover:bg-red-700">PDF Report</button>
          </div>
        </div>
      </div>

      <div className="max-w-[8.5in] mx-auto py-12 space-y-12">
        <div id="analysis-page" className="bg-white p-16 shadow-xl border border-slate-200 min-h-[11in]">
          <header className="mb-12">
            <div className="flex items-center justify-between">
              <img src={ACCO_NEW_LOGO} alt="ACCO" className="w-24 h-auto" />
              <div className="text-right"><p className="text-3xl font-black text-[#084C7C] leading-none uppercase tracking-tighter">TECHNICAL ANALYSIS<br />REPORT</p></div>
            </div>
            <div className="w-full h-1 bg-[#084C7C] mt-8 mb-10"></div>
            <div className="grid grid-cols-4 border border-slate-100 bg-slate-50/50 p-4">
              <div><span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Client</span><span className="font-bold text-[#084C7C] text-[11px] uppercase truncate block">{data.customerName}</span></div>
              <div><span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Address</span><span className="font-bold text-[#084C7C] text-[11px] uppercase truncate block">{data.address}</span></div>
              <div><span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Tech</span><span className="font-bold text-[#084C7C] text-[11px] uppercase truncate block">{data.technicianName}</span></div>
              <div><span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Date</span><span className="font-bold text-[#084C7C] text-[11px] uppercase truncate block">{data.date}</span></div>
            </div>
          </header>

          <section className="mb-12">
            <h3 className="text-[#084C7C] text-[11px] font-black uppercase tracking-[0.2em] mb-6 flex items-center border-b border-slate-100 pb-2">
              <FileText className="w-4 h-4 mr-2" /> Executive Summary & Assessment
            </h3>
            <div className="bg-slate-50 p-8 border-l-4 border-[#084C7C]">
              <div className="flex gap-12 mb-6 border-b border-slate-200 pb-6">
                 <div><span className="text-2xl font-black uppercase" style={{ color: getRatingColor(data.summary.conditionRating) }}>{data.summary.conditionRating}</span></div>
                 <div className="border-l border-slate-200 pl-12"><span className="text-2xl font-black uppercase text-[#084C7C]">Grade {data.summary.nasscoGrade} / 5</span></div>
              </div>
              <p className="text-slate-700 text-[14px] font-black leading-relaxed mb-4">{data.summary.summaryText}</p>
              <p className="text-slate-500 text-[13px] leading-relaxed italic">{data.summary.detailedServiceSummary}</p>
            </div>
          </section>

          <section className="mb-12">
            <h3 className="text-[#084C7C] text-[11px] font-black uppercase tracking-[0.2em] mb-6 flex items-center border-b border-slate-100 pb-2">
              <ClipboardList className="w-4 h-4 mr-2" /> Video Inspection Analysis Notes
            </h3>
            <div className="bg-slate-50/50 p-8 border border-slate-100 rounded-sm">
              <p className="text-slate-700 text-[14px] leading-relaxed whitespace-pre-line">{data.technicianNotes}</p>
            </div>
          </section>

          <section className="mb-12">
            <h3 className="text-[#084C7C] text-[11px] font-black uppercase tracking-[0.2em] mb-10 flex items-center border-b border-slate-100 pb-2">
              <Activity className="w-4 h-4 mr-2" /> Detailed Inspection Findings
            </h3>
            <div className="space-y-16">
              {displayedFindings.map((f) => {
                const s = getSeverityStyles(f.severity);
                const isEditing = editingFindingId === f.id;
                const isSyncing = isSyncingId === f.id;
                const status = f.status || 'pending';
                const isRejected = status === 'rejected';

                return (
                  <div key={f.id} className={`relative border-b border-slate-100 pb-12 last:border-0 ${isRejected ? 'opacity-50 no-print bg-red-50/5' : ''}`}>
                    <div className="no-print absolute top-0 right-0 flex gap-2">
                      {!isEditing && !isRejected && status === 'pending' && (
                        <>
                          <button 
                            disabled={isSyncing}
                            onClick={() => confirmFinding(f.id)} 
                            className="bg-green-50 hover:bg-green-100 text-green-700 text-[9px] font-black px-3 py-1 uppercase tracking-widest flex items-center transition-all rounded-sm border border-green-200 disabled:opacity-50 shadow-sm"
                          >
                            {isSyncing && isSyncingId === f.id ? <><Loader2 className="w-3 h-3 mr-1 animate-spin" /> ...</> : <><CheckCircle2 className="w-3 h-3 mr-1" /> Confirm</>}
                          </button>
                          <button 
                            disabled={isSyncing}
                            onClick={() => startEdit(f)} 
                            className="bg-slate-50 hover:bg-slate-100 text-[#00478B] text-[9px] font-black px-3 py-1 uppercase tracking-widest flex items-center transition-all rounded-sm border border-slate-200 disabled:opacity-50 shadow-sm"
                          >
                            <Edit3 className="w-3 h-3 mr-1" /> Train AI
                          </button>
                          <button 
                            disabled={isSyncing}
                            onClick={() => rejectFinding(f.id)} 
                            className="bg-red-50 hover:bg-red-100 text-red-600 text-[9px] font-black px-3 py-1 uppercase tracking-widest flex items-center transition-all rounded-sm border border-red-200 disabled:opacity-50 shadow-sm"
                          >
                            {isSyncing && isSyncingId === f.id ? <><Loader2 className="w-3 h-3 mr-1 animate-spin" /> ...</> : <><Trash2 className="w-3 h-3 mr-1" /> Reject</>}
                          </button>
                        </>
                      )}
                      
                      {isRejected && (
                        <div className="text-red-600 text-[9px] font-black uppercase tracking-widest py-1 px-3 bg-red-100 border border-red-200 flex items-center gap-1 rounded-sm shadow-sm">
                          <XCircle className="w-3.5 h-3.5" /> Rejected
                        </div>
                      )}

                      {status === 'confirmed' && !isEditing && (
                        <div className="text-green-600 text-[9px] font-black uppercase tracking-widest py-1 px-3 bg-green-50 border border-green-100 flex items-center gap-1 rounded-sm shadow-sm">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Confirmed
                        </div>
                      )}
                      {status === 'trained' && !isEditing && (
                        <div className="text-blue-600 text-[9px] font-black uppercase tracking-widest py-1 px-3 bg-blue-50 border border-blue-100 flex items-center gap-1 rounded-sm shadow-sm">
                          <Zap className="w-3.5 h-3.5" /> Trained
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 mb-4">
                      <div className="bg-[#084C7C] text-white px-2 py-0.5 text-[9px] font-black uppercase tracking-widest rounded-sm">{f.pacpCode}</div>
                      <div className="px-2 py-0.5 text-[9px] font-black uppercase tracking-widest rounded-sm" style={{ backgroundColor: s.bg, color: s.text }}>{s.label}</div>
                    </div>

                    {isEditing ? (
                      <div className="bg-[#002B5B] p-8 mb-8 border-l-[8px] border-blue-400 relative rounded-sm shadow-2xl z-[60] text-white">
                        <button disabled={isSyncing} onClick={() => setEditingFindingId(null)} className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors"><XCircle className="w-5 h-5" /></button>
                        <div className="grid grid-cols-2 gap-8">
                          <div>
                            <label className="text-[10px] font-black text-blue-200 uppercase block mb-2 tracking-widest">Headline Correction</label>
                            <input value={editForm.type} onChange={e => setEditForm({...editForm, type: e.target.value})} className="w-full p-3 rounded-sm text-sm bg-white text-[#002B5B] font-bold border-none outline-none" />
                          </div>
                          <div>
                            <label className="text-[10px] font-black text-blue-200 uppercase block mb-2 tracking-widest">Severity Override</label>
                            <select value={editForm.severity} onChange={e => setEditForm({...editForm, severity: e.target.value as Severity})} className="w-full p-3 rounded-sm text-sm bg-white text-[#002B5B] font-bold border-none outline-none cursor-pointer">
                              <option value={Severity.GRADE5}>Grade 5 - Critical</option>
                              <option value={Severity.GRADE4}>Grade 4 - Poor</option>
                              <option value={Severity.GRADE3}>Grade 3 - Fair</option>
                              <option value={Severity.GRADE2}>Grade 2 - Minor</option>
                              <option value={Severity.GRADE1}>Grade 1 - Normal</option>
                            </select>
                          </div>
                        </div>
                        <button onClick={() => saveCorrection(f.id)} disabled={isSyncing} className="mt-6 bg-white text-[#002B5B] font-black px-10 py-3 text-[11px] uppercase tracking-widest rounded-sm hover:bg-blue-50 flex items-center gap-2 transition-all shadow-lg">
                          {isSyncing ? <><Loader2 className="w-4 h-4 animate-spin" /> Syncing Batch...</> : 'Save & Train AI'}
                        </button>
                      </div>
                    ) : <h4 className="text-2xl font-black text-[#084C7C] uppercase tracking-tighter mb-4">{f.issueType}</h4>}

                    {!isEditing && (
                      <div className="bg-white border border-slate-100 border-l-4 border-blue-600 p-5 mb-8 rounded-sm shadow-sm flex gap-4 items-start">
                        <div className="bg-blue-50 p-2 rounded-sm"><Wrench className="w-4 h-4 text-blue-600" /></div>
                        <div>
                          <span className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] mb-1 block">Recommendation</span>
                          <p className="text-[#084C7C] text-[16px] font-bold leading-tight uppercase tracking-tight">{f.remediationMethod || "Further inspection required."}</p>
                        </div>
                      </div>
                    )}

                    <div className="bg-blue-50/30 border-l border-blue-200/50 p-6 mb-6 flex gap-4">
                      <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-1" />
                      <div><span className="block text-[8px] font-black text-slate-400 uppercase mb-2">Technical Standard Reference</span><p className="text-slate-600 text-[13px] italic leading-relaxed">{f.standardDescription}</p></div>
                    </div>

                    <p className="text-slate-600 text-[14px] leading-relaxed mb-8">{f.description}</p>
                    <div className="grid grid-cols-2 gap-6 mb-8">
                      {f.occurrences.map((occ) => (
                        <div key={`${f.id}-occ-${occ.frameIndex}`} className="group relative aspect-video bg-black rounded-sm overflow-hidden border border-slate-200 shadow-sm transition-transform hover:scale-[1.01]">
                          <img src={getFrameImage(occ.frameIndex)} className="w-full h-full object-cover" />
                          <div className="absolute top-2 right-2 bg-black/70 px-2 py-0.5 text-[8px] text-white font-black">{occ.distance}</div>
                          {isEditing && f.occurrences.length > 1 && (
                            <button 
                              onClick={() => removeOccurrence(f.id, occ.frameIndex)}
                              className="no-print absolute top-2 left-2 bg-red-600 text-white p-1.5 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:bg-red-700"
                              title="Remove this frame from finding"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          <section className="mb-20 no-print border-t border-slate-100 pt-12">
            <div className="bg-slate-50 border border-slate-200 p-8 rounded-sm">
              <div className="flex items-center gap-3 mb-6">
                <Zap className="w-6 h-6 text-blue-600" />
                <h3 className="text-[#084C7C] text-[13px] font-black uppercase tracking-widest">Did the AI miss something? Initiate targeted rescan.</h3>
              </div>
              <textarea
                disabled={isRescanning}
                value={rescanGuidance}
                onChange={(e) => setRescanGuidance(e.target.value)}
                placeholder="Enter focused guidance for the AI..."
                className="w-full bg-white border border-slate-200 p-4 rounded-sm text-sm font-medium outline-none h-24 resize-none mb-4 focus:ring-1 focus:ring-blue-400 transition-all"
              />
              <div className="flex justify-end">
                <button
                  disabled={isRescanning || !rescanGuidance.trim()}
                  onClick={handleTargetedRescan}
                  className="bg-[#084C7C] text-white px-8 py-3 rounded-sm text-[10px] font-black uppercase tracking-widest hover:bg-slate-800 flex items-center gap-2 disabled:opacity-30 transition-all shadow-md"
                >
                  {isRescanning ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Activity className="w-4 h-4" /> Trigger Target Rescan</>}
                </button>
              </div>
            </div>
          </section>
        </div>

        {showProposal && (
          <div id="proposal-page" className="bg-white p-16 shadow-xl border border-slate-200 print-break min-h-[11in]">
            <header className="mb-14 text-center">
              <h1 className="text-2xl font-black text-[#084C7C] uppercase tracking-[0.3em] mb-4">REMEDIATION PROPOSAL</h1>
              <div className="h-1 w-20 bg-[#D31245] mx-auto mb-8"></div>
            </header>
            
            <table className="w-full border-collapse mt-12 mb-20">
              <thead>
                <tr className="bg-[#084C7C] text-white text-[9px] font-black uppercase tracking-widest">
                  <th className="p-4 text-left w-56">Severity</th>
                  <th className="p-4 text-left">Description</th>
                  <th className="p-4 text-left">Method</th>
                  <th className="p-4 text-right">Investment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {exportedFindings.map(f => {
                  const sev = getSeverityStyles(f.severity);
                  return (
                    <tr key={f.id}>
                      <td className="p-6 align-middle">
                        <span className="text-[9px] font-black px-4 py-2 rounded-sm uppercase tracking-widest block text-center" style={{ backgroundColor: sev.bg, color: sev.text }}>{sev.label}</span>
                      </td>
                      <td className="p-6"><h5 className="font-black text-[#084C7C] uppercase text-[12px]">{f.issueType}</h5></td>
                      <td className="p-6 text-slate-600 text-[11px] font-bold">{f.remediationMethod}</td>
                      <td className="p-6 text-right font-black text-[#084C7C] text-md">$ ________.00</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            <div className="flex justify-end mb-16 px-4">
              <div className="bg-slate-50 border border-slate-200 p-8 rounded-sm w-[400px]">
                <div className="flex justify-between items-center text-[#084C7C]">
                  <span className="text-[14px] font-black uppercase tracking-widest">Total Project Investment:</span>
                  <div className="text-right">
                    <span className="text-2xl font-black">$ ________.00</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="border border-slate-100 rounded-sm p-12 bg-white">
              <h3 className="text-[#084C7C] text-[13px] font-black uppercase tracking-widest mb-10 border-b border-slate-100 pb-4">Project Authorization & Acceptance</h3>
              <div className="grid grid-cols-2 gap-x-20 gap-y-16">
                <div className="relative">
                  <div className="border-b border-slate-900 h-10 w-full mb-2"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Customer Acceptance Signature</span>
                </div>
                <div className="relative">
                  <div className="border-b border-slate-900 h-10 w-full mb-2"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Date</span>
                </div>
                <div className="relative">
                  <div className="border-b border-slate-900 h-10 w-full mb-2"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Print Name</span>
                </div>
                <div className="relative">
                  <div className="border-b border-slate-900 h-10 w-full mb-2"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Investment</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <button 
        onClick={() => setShowTrace(true)}
        className="fixed bottom-8 right-8 z-[100] bg-[#001D3D] text-white px-6 py-4 rounded-full shadow-2xl border border-white/10 hover:bg-slate-800 transition-all no-print flex items-center gap-3 group"
      >
        <Terminal className="w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform" />
        <span className="text-[10px] font-black uppercase tracking-[0.2em]">Technical Trace</span>
      </button>

      {showTrace && (
        <div className="fixed inset-0 z-[1000] no-print flex justify-end">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setShowTrace(false)}></div>
          <div className="relative w-full max-w-md bg-[#001D3D] shadow-2xl border-l border-white/10 flex flex-col h-full animate-slide-in">
            <div className="p-6 bg-slate-900 border-b border-white/10 flex justify-between items-center">
              <h3 className="text-white font-black text-xs uppercase tracking-[0.3em] flex items-center gap-2">
                <Terminal className="w-4 h-4 text-blue-400" /> Analysis Technical Trace
              </h3>
              <div className="flex gap-4">
                <button onClick={copyLogs} className="text-white/50 hover:text-white transition-colors" title="Copy Logs">
                  {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
                <button onClick={() => setShowTrace(false)} className="text-white/50 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-4 font-mono text-[10px]">
              {logs.length === 0 ? (
                <div className="text-white/20 italic">No trace data available...</div>
              ) : (
                logs.map(log => (
                  <div key={log.id} className="border-b border-white/5 pb-3 last:border-0">
                    <div className="flex gap-3 mb-1">
                      <span className="text-white/30">{log.timestamp}</span>
                      <span className={`font-black uppercase ${
                        log.type === 'error' ? 'text-red-400' : 
                        log.type === 'success' ? 'text-green-400' : 
                        log.type === 'network' ? 'text-blue-400' : 'text-slate-400'
                      }`}>[{log.type}]</span>
                    </div>
                    <p className="text-white/80 leading-relaxed whitespace-pre-wrap">{log.message}</p>
                    {log.details && (
                      <pre className="text-white/40 mt-1 whitespace-pre-wrap text-[9px] bg-black/20 p-2 rounded-sm">
                        {JSON.stringify(log.details, null, 2)}
                      </pre>
                    )}
                  </div>
                ))
              )}
            </div>
            <div className="p-4 bg-slate-900 border-t border-white/10">
              <button onClick={() => { logRecorder.clear(); setShowTrace(false); }} className="w-full py-2 bg-red-900/30 text-red-400 text-[10px] font-black uppercase tracking-widest hover:bg-red-900/50 transition-colors">Clear Trace History</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slide-in {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
        .animate-slide-in {
          animation: slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
      `}</style>
    </div>
  );
};

export default InspectionReport;