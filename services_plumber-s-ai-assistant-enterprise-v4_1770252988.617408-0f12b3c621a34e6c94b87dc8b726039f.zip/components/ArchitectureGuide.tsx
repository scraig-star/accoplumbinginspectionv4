
import React from 'react';
import { X, Server, Database, Cloud, Zap, ShieldCheck, Cpu } from 'lucide-react';

interface Props {
  onClose: () => void;
}

const ArchitectureGuide: React.FC<Props> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 md:p-8 bg-[#001D3D]/95 backdrop-blur-md overflow-y-auto">
      <div className="max-w-4xl w-full bg-white rounded-sm shadow-2xl overflow-hidden relative">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-900 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-8 md:p-12">
          <header className="mb-10">
            <div className="flex items-center gap-3 mb-2">
              <Zap className="w-5 h-5 text-[#D31245]" />
              <span className="text-[10px] font-black text-[#D31245] uppercase tracking-[0.3em]">Infrastructure Blueprint</span>
            </div>
            <h2 className="text-3xl font-black text-[#001D3D] uppercase tracking-tighter">Plumber's AI Assistant Architecture</h2>
            <p className="text-slate-500 mt-2 font-medium">Technical summary of the serverless event-driven pipeline.</p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="space-y-6">
              <section>
                <h3 className="flex items-center text-[11px] font-black text-slate-900 uppercase tracking-widest mb-4">
                  <Server className="w-4 h-4 mr-2 text-blue-600" /> 1. Export Bridge (Cloud Function)
                </h3>
                <div className="bg-slate-50 p-5 border-l-4 border-blue-600 rounded-sm">
                  <p className="text-xs font-bold text-slate-700 leading-relaxed">
                    Name: <code className="bg-blue-100 px-1 text-blue-800">acco-firestore-to-jsonl-export</code><br/>
                    Runtime: Node.js 24 (Ubuntu 24)<br/>
                    Entry Point: <code className="bg-blue-100 px-1 text-blue-800">exportFirestoreToJSONL</code>
                  </p>
                  <p className="text-[11px] text-slate-500 mt-3 italic">
                    Converts verified Firestore findings into JSONL format for Gemini fine-tuning.
                  </p>
                </div>
              </section>

              <section>
                <h3 className="flex items-center text-[11px] font-black text-slate-900 uppercase tracking-widest mb-4">
                  <Cpu className="w-4 h-4 mr-2 text-blue-600" /> 2. Scaling & Revision
                </h3>
                <ul className="space-y-2 text-xs text-slate-600 font-medium">
                  <li className="flex justify-between border-b border-slate-100 pb-2">
                    <span>Max Instances</span>
                    <span className="font-bold text-slate-900">10 (Billing Cap)</span>
                  </li>
                  <li className="flex justify-between border-b border-slate-100 pb-2">
                    <span>Memory Allocation</span>
                    <span className="font-bold text-slate-900">1 GiB</span>
                  </li>
                  <li className="flex justify-between">
                    <span>CPU Boost</span>
                    <span className="font-bold text-green-600 uppercase">Enabled</span>
                  </li>
                </ul>
              </section>
            </div>

            <div className="space-y-6">
              <section>
                <h3 className="flex items-center text-[11px] font-black text-slate-900 uppercase tracking-widest mb-4">
                  <Database className="w-4 h-4 mr-2 text-blue-600" /> 3. Environment Variables
                </h3>
                <div className="bg-slate-900 p-5 rounded-sm text-blue-300 font-mono text-[10px] space-y-2">
                  <div>GCS_BUCKET_NAME = "acco-inspection-training-data"</div>
                  <div>FIRESTORE_COLLECTION = "corrections"</div>
                </div>
              </section>

              <section>
                <h3 className="flex items-center text-[11px] font-black text-slate-900 uppercase tracking-widest mb-4">
                  <ShieldCheck className="w-4 h-4 mr-2 text-blue-600" /> 4. Security & IAM
                </h3>
                <div className="bg-green-50 p-5 border border-green-100 rounded-sm">
                  <p className="text-[11px] font-bold text-green-800 mb-2 uppercase tracking-tight">Required Roles for Service Account:</p>
                  <ul className="list-disc list-inside text-[11px] text-green-700 space-y-1">
                    <li>Cloud Datastore User (Firestore Read)</li>
                    <li>Storage Object Admin (GCS Write)</li>
                  </ul>
                </div>
              </section>
            </div>
          </div>

          <section className="bg-slate-50 p-8 rounded-sm border border-slate-200">
            <h3 className="flex items-center text-[11px] font-black text-slate-900 uppercase tracking-widest mb-6">
              <Cloud className="w-4 h-4 mr-2 text-blue-600" /> High-Level Workflow (Phase 1-3)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
              <div className="relative z-10 text-center">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-xs">1</div>
                <h4 className="text-[10px] font-black uppercase text-slate-900 mb-1">Feedback</h4>
                <p className="text-[10px] text-slate-500">App saves verified corrections to Firestore</p>
              </div>
              <div className="relative z-10 text-center">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-xs">2</div>
                <h4 className="text-[10px] font-black uppercase text-slate-900 mb-1">Extraction</h4>
                <p className="text-[10px] text-slate-500">Cloud Function bundles data into JSONL file in GCS</p>
              </div>
              <div className="relative z-10 text-center">
                <div className="w-8 h-8 bg-[#D31245] text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-xs">3</div>
                <h4 className="text-[10px] font-black uppercase text-slate-900 mb-1">Fine-Tuning</h4>
                <p className="text-[10px] text-slate-500">Vertex AI tunes Gemini 1.5 Flash using JSONL dataset</p>
              </div>
            </div>
          </section>

          <footer className="mt-12 pt-8 border-t border-slate-100 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Pipeline Status: Operational</span>
            </div>
            <button 
              onClick={onClose}
              className="px-8 py-3 bg-[#001D3D] text-white text-[10px] font-black uppercase tracking-widest rounded-sm hover:bg-slate-800 transition-colors"
            >
              Close Reference
            </button>
          </footer>
        </div>
      </div>
    </div>
  );
};

export default ArchitectureGuide;
