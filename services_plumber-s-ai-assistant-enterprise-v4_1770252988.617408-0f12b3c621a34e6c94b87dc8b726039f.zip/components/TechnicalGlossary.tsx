
import React from 'react';

/**
 * ACCO ENTERPRISE: TECHNICAL GLOSSARY & FILE BLUEPRINT
 * 
 * Updated with deep-dives into configuration files and infrastructure concepts.
 */
const TechnicalGlossary: React.FC = () => {
  
  const coreConcepts = [
    {
      term: "Base64 Encoding",
      analogy: "Digital Wrapping Paper",
      description: "Turns image files into text strings so they can be sent via JSON. Essential for 'Training' the AI with new evidence."
    },
    {
      term: "Middleware",
      analogy: "The Filter System",
      description: "Functions in server.js that process requests BEFORE they reach the API. Used for security, logging, and fixing path mismatches like '/api-proxy'."
    },
    {
      term: "CORS (Cross-Origin Resource Sharing)",
      analogy: "The ID Check",
      description: "A security feature that prevents unauthorized websites from talking to your backend. cors.json handles this for your GCS buckets."
    },
    {
      term: "Express.js Routing",
      analogy: "The Switchboard",
      description: "The logic that maps a URL (like /api/v1/upload) to a specific function in your code. When this fails, you get a 404 error."
    }
  ];

  const fileDeepDive = [
    {
      file: "services/apiConfig.ts",
      role: "The Internal Compass",
      purpose: "Tells the frontend how to find the backend. By using relative paths, we ensure the browser always looks on the same server, which bypasses many complex cloud-proxy issues."
    },
    {
      file: "cors.json",
      role: "The Storage Gatekeeper",
      purpose: "Specifically configures the Google Cloud Storage bucket. It tells GCP: 'It is okay for a browser to upload files directly here if they come from a trusted source'."
    },
    {
      file: "server.js",
      role: "The Operational Hub",
      purpose: "This is where the 'Plumbing' happens. It handles the 'Train AI' button by proxying data to Firestore and Storage. It is the only part of your app that has 'Write' permissions to the Cloud."
    },
    {
      file: "package.json",
      role: "The Supply List",
      purpose: "Lists every tool used (Express, Google SDKs). When you deploy, Cloud Run reads this file to know what software to install in the container."
    }
  ];

  // LOGGING TO CONSOLE FOR REFERENCE
  console.log("--- ACCO TECHNICAL BLUEPRINT ---");
  console.table(coreConcepts);
  console.table(fileDeepDive);

  return null;
};

export default TechnicalGlossary;
