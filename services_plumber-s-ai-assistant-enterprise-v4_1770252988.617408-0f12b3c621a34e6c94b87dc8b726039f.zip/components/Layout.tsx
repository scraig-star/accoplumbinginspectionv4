import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const ACCO_LOGO_URL = "https://raw.githubusercontent.com/scraig-star/acco-assetsseangoogleaitest/d618f79aa46c180d31c283409e6c8d7757dfa5e3/ACCO%20original%20logo_Large%20Format.png";

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-900 bg-slate-50">
      <nav className="bg-white border-b border-slate-200 shadow-sm no-print z-50 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <div className="flex items-center gap-4">
                <img src={ACCO_LOGO_URL} alt="ACCO Engineered Systems" className="h-12 w-auto object-contain" />
              </div>
              <div className="hidden md:ml-8 md:flex md:space-x-8 h-full items-center">
                <span className="border-l border-slate-300 pl-6 text-slate-500 text-[10px] font-bold uppercase tracking-widest">
                  Plumbing Inspection Analysis Tool
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="flex flex-col text-right hidden sm:flex">
                <span className="text-sm font-bold text-slate-900">John Rossoni</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-black">Sr. Mgr. Tech & Ops</span>
              </div>
              <div className="h-10 w-10 rounded-sm bg-[#001D3D] text-white flex items-center justify-center font-bold shadow-sm">
                JR
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow w-full mx-auto max-w-none p-0">
        {children}
      </main>

      <footer className="bg-[#1a1a1a] text-slate-400 py-6 text-center no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-sm font-light">
            © 2025 ACCO Engineered Systems.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;