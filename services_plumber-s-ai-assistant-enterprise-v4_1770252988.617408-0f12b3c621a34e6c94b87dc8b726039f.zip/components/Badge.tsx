
import React from 'react';
import { Severity } from '../types';

interface BadgeProps {
  severity: Severity;
}

const Badge: React.FC<BadgeProps> = ({ severity }) => {
  let classes = "px-2.5 py-0.5 rounded-full text-xs font-medium border ";

  switch (severity) {
    case Severity.GRADE5:
      classes += "bg-red-200 text-red-900 border-red-300";
      break;
    case Severity.GRADE4:
      classes += "bg-red-100 text-red-800 border-red-200";
      break;
    case Severity.GRADE3:
      classes += "bg-yellow-100 text-yellow-800 border-yellow-200";
      break;
    case Severity.GRADE2:
      classes += "bg-lime-100 text-lime-800 border-lime-200";
      break;
    case Severity.GRADE1:
    default:
      classes += "bg-green-100 text-green-800 border-green-200";
      break;
  }

  return (
    <span className={classes}>
      Grade {severity}
    </span>
  );
};

export default Badge;
