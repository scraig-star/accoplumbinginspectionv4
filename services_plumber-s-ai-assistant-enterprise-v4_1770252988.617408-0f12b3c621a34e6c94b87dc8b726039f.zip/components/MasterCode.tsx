import React, { useState, useMemo } from 'react';
import { X, FileCode, Search, ChevronRight, Copy, Check, Terminal } from 'lucide-react';

interface Props {
  onClose: () => void;
}

const MasterCode: React.FC<Props> = ({ onClose }) => {
  const [selectedFile, setSelectedFile] = useState<string>('App.tsx');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const projectSource: Record<string, string> = {
    'index.tsx': `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,
    'App.tsx': `// Application Entry Point - Dashboard & Layout Logic`,
    'services/apiConfig.ts': `/**
 * CLOUD RUN PROXY CONFIGURATION
 */
const getBaseUrl = () => {
  if (typeof window === 'undefined') return '';
  let override = localStorage.getItem('ACCO_API_GATEWAY');
  if (override) {
    override = override.trim();
    if (!override.startsWith('http://') && !override.startsWith('https://')) {
      override = 'https://' + override;
    }
    return override.endsWith('/') ? override.slice(0, -1) : override;
  }
  return ''; // Default to relative path for unified production
};

export const BASE_URL = getBaseUrl();
export const STORAGE_BUCKET_NAME = "acco-inspection-training-data";
export const API_ENDPOINTS = {
  UPLOAD_IMAGE: '/api/v1/upload-image',
  SAVE_CORRECTION: '/api/v1/log-correction',
  PING: '/api/v1/ping'
};`,
    'Dockerfile': `FROM node:22-slim
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 8080
CMD [ "npm", "start" ]`,
    '.gcloudignore': `.gcloudignore
.git
.gitignore
node_modules
.dockerignore
.vscode
npm-debug.log`,
    'server.js': `// Node.js Backend Proxy & Asset Server`
  };

  const filteredFiles = useMemo(() => {
    return Object.keys(projectSource).filter(f => f.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [searchQuery]);

  const copyCode = () => {
    navigator.clipboard.writeText(projectSource[selectedFile]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[500] flex bg-slate-950 font-sans text-slate-300">
      <div className="w-80 border-r border-slate-800 flex flex-col bg-slate-900/50">
        <div className="p-6 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-green-500/10 rounded-sm">
              <FileCode className="w-5 h-5 text-green-400" />
            </div>
            <h1 className="text-sm font-black text-white uppercase tracking-[0.2em]">Master Source</h1>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Filter files..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-sm py-2 pl-10 pr-4 text-xs font-medium outline-none focus:border-green-500 transition-colors"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto py-4">
          {filteredFiles.map(file => (
            <button
              key={file}
              onClick={() => setSelectedFile(file)}
              className={`w-full text-left px-6 py-2.5 text-[11px] font-bold uppercase tracking-widest flex items-center transition-all ${selectedFile === file ? 'bg-green-500/10 text-green-400 border-r-2 border-green-400' : 'text-slate-500 hover:bg-slate-800 hover:text-slate-300'}`}
            >
              <ChevronRight className={`w-3 h-3 mr-2 transition-transform ${selectedFile === file ? 'rotate-90' : ''}`} />
              {file}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-8">
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Selected File:</span>
            <span className="text-xs font-mono font-bold text-green-400">{selectedFile}</span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={copyCode}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 rounded-sm transition-all"
            >
              {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied' : 'Copy Source'}
            </button>
            <button 
              onClick={onClose}
              className="p-2 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </header>
        <div className="flex-1 relative overflow-hidden bg-[#0a0a0a]">
          <div className="absolute inset-0 overflow-auto p-8 font-mono text-[13px] leading-relaxed">
            <table className="w-full border-collapse">
              <tbody>
                {projectSource[selectedFile] ? projectSource[selectedFile].split('\n').map((line, i) => (
                  <tr key={i} className="group hover:bg-white/5">
                    <td className="w-12 text-right pr-6 text-slate-600 select-none border-r border-slate-800/50 group-hover:text-slate-400">{i + 1}</td>
                    <td className="pl-6 whitespace-pre text-slate-300">{line}</td>
                  </tr>
                )) : <tr><td className="p-4 italic text-slate-500">File not found in registry.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MasterCode;