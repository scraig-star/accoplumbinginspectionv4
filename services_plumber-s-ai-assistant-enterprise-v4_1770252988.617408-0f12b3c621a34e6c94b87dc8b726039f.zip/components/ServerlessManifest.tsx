
import React from 'react';

/**
 * ACCO INFRASTRUCTURE & DEPLOYMENT MANIFEST
 * This file acts as a central registry for serverless deployment code and IAM fixes.
 * 
 * TARGET PROJECT: plumber-s-ai-assistant-enterprise-131631609347
 * TARGET SERVICE ACCOUNT: 131631609347-compute@developer.gserviceaccount.com
 */

export const DEPLOYMENT_BLUEPRINTS = {
  DOCKERFILE: `
FROM node:22-slim
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 8080
CMD [ "npm", "start" ]
  `.trim(),

  CLOUD_RUN_SERVICE_YAML: `
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: plumber-s-ai-assistant-enterprise
  labels:
    cloud.googleapis.com/location: us-west1
spec:
  template:
    spec:
      containers:
      - image: us-west1-docker.pkg.dev/plumber-s-ai-assistant-enterprise-131631609347/acco-repo/proxy:latest
        ports:
        - containerPort: 8080
        volumeMounts:
        - name: dist-volume
          mountPath: /app/dist
      volumes:
      - name: dist-volume
        csi:
          driver: gcsfuse.run.google.com
          volumeAttributes:
            bucketName: acco-inspection-training-data
            mountOptions: "only-dir=services/plumber-s-ai-assistant-enterprise/version-92/compiled"
  `.trim(),

  CLOUD_FUNCTION: `
/**
 * ACCO Export Bridge: Firestore to GCS JSONL
 * Trigger: HTTP (Manual/Scheduled)
 */
const { Firestore } = require('@google-cloud/firestore');
const { Storage } = require('@google-cloud/storage');
const firestore = new Firestore();
const storage = new Storage();

exports.exportFirestoreToJSONL = async (req, res) => {
  try {
    const bucketName = 'acco-inspection-training-data';
    const snapshot = await firestore.collection('corrections')
      .where('status', '==', 'pending_jsonl_export')
      .get();

    if (snapshot.empty) return res.status(200).send("No pending data.");

    let jsonl = "";
    const batch = firestore.batch();

    snapshot.forEach(doc => {
      const data = doc.data();
      jsonl += JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [
              { text: "Analyze for corrections." },
              { fileData: { fileUri: data.imageGcsUri, mimeType: "image/jpeg" } }
            ]
          },
          {
            role: "model",
            parts: [
              { text: \`Corrected Type: \${data.correctedType}, Severity: \${data.correctedSeverity}\` }
            ]
          }
        ]
      }) + "\\n";
      batch.update(doc.ref, { status: 'exported_to_jsonl' });
    });

    const filename = \`datasets/tuning_\${Date.now()}.jsonl\`;
    await storage.bucket(bucketName).file(filename).save(jsonl);
    await batch.commit();
    
    res.status(200).json({ success: true, count: snapshot.size, uri: filename });
  } catch (err) {
    res.status(500).send(err.message);
  }
};
  `.trim(),

  IAM_TROUBLESHOOTING: `
# --------------------------------------------------------------------------
# ACCO PIPELINE: SERVICE ACCOUNT & CLOUD BUILD REPAIR SCRIPT
# Run these commands in the Google Cloud Shell to resolve "Status 9" errors.
# --------------------------------------------------------------------------

# 1. DEFINE PROJECT DETAILS
PROJECT_ID="plumber-s-ai-assistant-enterprise-131631609347"
PROJECT_NUMBER="131631609347"
COMPUTE_SA="131631609347-compute@developer.gserviceaccount.com"

# 2. FIX CLOUD BUILD SERVICE AGENT (Resolves Status 9 / CreateBuild Failure)
# This grants the Cloud Build service account the internal identity it needs.
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:service-$PROJECT_NUMBER@gcp-sa-cloudbuild.iam.gserviceaccount.com" \
    --role="roles/cloudbuild.serviceAgent"

# 3. FIX COMPUTE SERVICE ACCOUNT PERMISSIONS (The provided account)
# Ensure the deployment account can write to Storage and Firestore.
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:$COMPUTE_SA" \
    --role="roles/storage.objectAdmin"

gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:$COMPUTE_SA" \
    --role="roles/datastore.user"

# 4. RECREATE IDENTITY IF DELETED
gcloud beta services identity create --service=cloudbuild.googleapis.com --project=$PROJECT_ID
  `.trim()
};

const ServerlessManifest: React.FC = () => {
  return null; // Headless component
};

export default ServerlessManifest;
