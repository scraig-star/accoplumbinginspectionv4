import React, { useReducer, useEffect, useState } from 'react';
import Layout from './components/Layout.tsx';
import InspectionReport from './components/InspectionReport.tsx';
import ArchitectureGuide from './components/ArchitectureGuide.tsx';
import TechnicalGlossary from './components/TechnicalGlossary.tsx';
import ServerlessManifest from './components/ServerlessManifest.tsx';
import MasterCode from './components/MasterCode.tsx';
import { extractFramesFromVideo } from './services/videoService.ts';
import { processVideoInBatches } from './services/geminiService.ts';
import { logRecorder } from './services/logService.ts';
import { API_ENDPOINTS, BASE_URL } from './services/apiConfig.ts';
import { InspectionData, FrameData, LogEntry } from './types.ts';
import { 
  Upload, PlayCircle, ChevronRight, CheckCircle2, FileText, ArrowRight, Eye, Smartphone, 
  Monitor, Wifi, Terminal, X, Copy, Check, Loader2, AlertTriangle, Layers, FileCode, Settings, Globe
} from 'lucide-react';

const DASHBOARD_BACKSPLASH_URL = "https://raw.githubusercontent.com/scraig-star/acco-assetsseangoogleaitest/9f3443041c44a0f155c2b23b596de1e5e7fc0258/3Q0A3420%20Plumbing%20Shop%20Photo%20Commerce%202024.JPG";
const PROCESSING_BACKSPLASH_URL = "https://raw.githubusercontent.com/scraig-star/acco-assetsseangoogleaitest/9f3443041c44a0f155c2b23b596de1e5e7fc0258/3Q0A3407%20Plumbing%20Shop%20Photo%202024.JPG";

type State = {
  view: 'dashboard' | 'processing' | 'proposal-ask' | 'report';
  file: File | null;
  processingStage: string;
  progress: number;
  reportData: InspectionData | null;
  extractedFrames: FrameData[];
  isMobileOptimized: boolean;
  showConsole: boolean;
  showArchitecture: boolean;
  showMasterCode: boolean;
  showSettings: boolean;
  isOnline: boolean | null;
  withProposal: boolean;
  client: string;
  technician: string;
  address: string;
  protocol: string;
  isDragging: boolean;
};

type Action = 
  | { type: 'SET_VIEW'; payload: State['view'] }
  | { type: 'SET_FILE'; payload: File | null }
  | { type: 'SET_PROGRESS'; payload: { stage: string; progress: number } }
  | { type: 'SET_REPORT'; payload: { data: InspectionData; frames: FrameData[] } }
  | { type: 'TOGGLE_MOBILE' }
  | { type: 'TOGGLE_CONSOLE' }
  | { type: 'TOGGLE_ARCHITECTURE' }
  | { type: 'TOGGLE_MASTER_CODE' }
  | { type: 'TOGGLE_SETTINGS' }
  | { type: 'SET_ONLINE'; payload: boolean }
  | { type: 'SET_PROPOSAL'; payload: boolean }
  | { type: 'SET_FIELD'; payload: { field: keyof State; value: string } }
  | { type: 'SET_DRAGGING'; payload: boolean };

const initialState: State = {
  view: 'dashboard',
  file: null,
  processingStage: '',
  progress: 0,
  reportData: null,
  extractedFrames: [],
  isMobileOptimized: false,
  showConsole: false,
  showArchitecture: false,
  showMasterCode: false,
  showSettings: false,
  isOnline: null,
  withProposal: false,
  client: '',
  technician: '',
  address: '',
  protocol: '',
  isDragging: false
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'SET_VIEW': return { ...state, view: action.payload };
    case 'SET_FILE': return { ...state, file: action.payload };
    case 'SET_PROGRESS': return { ...state, processingStage: action.payload.stage, progress: action.payload.progress };
    case 'SET_REPORT': return { ...state, reportData: action.payload.data, extractedFrames: action.payload.frames };
    case 'TOGGLE_MOBILE': return { ...state, isMobileOptimized: !state.isMobileOptimized };
    case 'TOGGLE_CONSOLE': return { ...state, showConsole: !state.showConsole };
    case 'TOGGLE_ARCHITECTURE': return { ...state, showArchitecture: !state.showArchitecture };
    case 'TOGGLE_MASTER_CODE': return { ...state, showMasterCode: !state.showMasterCode };
    case 'TOGGLE_SETTINGS': return { ...state, showSettings: !state.showSettings };
    case 'SET_ONLINE': return { ...state, isOnline: action.payload };
    case 'SET_PROPOSAL': return { ...state, withProposal: action.payload };
    case 'SET_FIELD': return { ...state, [action.payload.field]: action.payload.value };
    case 'SET_DRAGGING': return { ...state, isDragging: action.payload };
    default: return state;
  }
}

const App: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const [backendUrl, setBackendUrl] = useState(localStorage.getItem('ACCO_API_GATEWAY') || '');
  const [isTestingBackend, setIsTestingBackend] = useState(false);

  useEffect(() => {
    return logRecorder.subscribe(setLogs);
  }, []);

  useEffect(() => {
    const checkBackend = async () => {
      const endpoint = `${BASE_URL}${API_ENDPOINTS.PING}`;
      logRecorder.addLog('network', `Connectivity Check: GET ${endpoint}`);
      try {
        const res = await fetch(endpoint, { mode: 'cors' });
        dispatch({ type: 'SET_ONLINE', payload: res.ok });
        if (res.ok) {
          logRecorder.addLog('success', 'Backend reachable and healthy.');
        } else {
          logRecorder.addLog('warning', `Backend returned status ${res.status}. Switching to Edge mode.`);
        }
      } catch (e: any) {
        logRecorder.addLog('error', `Network Error: ${e.message}. Ensure the URL includes https:// and the server allows CORS.`);
        dispatch({ type: 'SET_ONLINE', payload: false });
      }
    };
    checkBackend();
  }, []);

  const handleSaveBackend = () => {
    let sanitized = backendUrl.trim();
    if (sanitized && !sanitized.startsWith('http://') && !sanitized.startsWith('https://')) {
      sanitized = 'https://' + sanitized;
    }
    if (sanitized.endsWith('/')) sanitized = sanitized.slice(0, -1);
    
    localStorage.setItem('ACCO_API_GATEWAY', sanitized);
    setBackendUrl(sanitized);
    logRecorder.addLog('info', `Backend Gateway updated: ${sanitized}. Reloading...`);
    window.location.reload(); 
  };

  const handleTestBackend = async () => {
    setIsTestingBackend(true);
    let sanitized = backendUrl.trim();
    if (!sanitized.startsWith('http://') && !sanitized.startsWith('https://')) {
      sanitized = 'https://' + sanitized;
    }
    if (sanitized.endsWith('/')) sanitized = sanitized.slice(0, -1);
    
    const testEndpoint = `${sanitized}${API_ENDPOINTS.PING}`;
    logRecorder.addLog('network', `Testing connectivity: GET ${testEndpoint}`);
    try {
      const res = await fetch(testEndpoint, { mode: 'cors' });
      if (res.ok) {
        logRecorder.addLog('success', 'Test Ping Successful');
        alert("Connection Successful!");
      } else {
        logRecorder.addLog('error', `Test Ping Failed: HTTP ${res.status}`);
        alert(`Connection failed with status: ${res.status}`);
      }
    } catch (e: any) {
      logRecorder.addLog('error', `Test Ping Exception: ${e.message}. Possible CORS or DNS issue.`);
      alert(`Connection failed: ${e.message}`);
    } finally {
      setIsTestingBackend(false);
    }
  };

  const handleStartProcessing = async () => {
    if (!state.file) return;
    try {
      logRecorder.clear();
      dispatch({ type: 'SET_VIEW', payload: 'processing' });
      dispatch({ type: 'SET_PROGRESS', payload: { stage: 'Extracting Frames...', progress: 5 } });
      
      const frames = await extractFramesFromVideo(state.file, 0.5, 2000);
      const result = await processVideoInBatches(frames, (stage, progress) => {
        dispatch({ type: 'SET_PROGRESS', payload: { stage, progress } });
      });

      const data: InspectionData = {
        customerName: state.client || 'ZARA', 
        address: state.address || 'Thousand Oaks Mall, CA', 
        technicianName: state.technician || 'John Rossoni',
        date: new Date().toLocaleDateString(), 
        videoName: state.file.name, 
        methodology: state.protocol || 'Standard Inspection',
        technicianAnalysis: "Completed.", 
        technicianNotes: result.technicianNotes || "Inspection complete.",
        findings: result.findings || [], 
        summary: result.summary || {} as any, 
        scopeOfWork: result.scopeOfWork || [], 
        totalFramesAnalyzed: frames.length
      };

      dispatch({ type: 'SET_REPORT', payload: { data, frames } });
      dispatch({ type: 'SET_VIEW', payload: 'proposal-ask' });
    } catch (error: any) {
      logRecorder.addLog('error', "Pipeline Failure", error);
      alert("Pipeline Failure.");
      dispatch({ type: 'SET_VIEW', payload: 'dashboard' });
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    dispatch({ type: 'SET_DRAGGING', payload: true });
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    dispatch({ type: 'SET_DRAGGING', payload: false });
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    dispatch({ type: 'SET_DRAGGING', payload: false });
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type.startsWith('video/')) {
      dispatch({ type: 'SET_FILE', payload: droppedFile });
      logRecorder.addLog('info', `Video dropped: ${droppedFile.name}`);
    } else {
      logRecorder.addLog('warning', "Invalid file type dropped. Please provide a video.");
    }
  };

  return (
    <Layout>
      <TechnicalGlossary />
      <ServerlessManifest />
      
      {state.showMasterCode && <MasterCode onClose={() => dispatch({ type: 'TOGGLE_MASTER_CODE' })} />}

      {state.showSettings && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-[#001D3D]/80 backdrop-blur-md no-print">
          <div className="w-full max-w-md bg-white rounded-sm shadow-2xl overflow-hidden border border-white/20">
            <div className="bg-[#0f172a] p-6 text-white flex justify-between items-center border-b border-white/10">
              <h3 className="text-xs font-black uppercase tracking-[0.2em] flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-400" /> Backend Connectivity
              </h3>
              <button onClick={() => dispatch({ type: 'TOGGLE_SETTINGS' })} className="text-white/50 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block">Cloud Run Proxy URL</label>
                <input 
                  type="text" 
                  placeholder="https://your-service-xyz.a.run.app" 
                  value={backendUrl}
                  onChange={(e) => setBackendUrl(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-sm p-4 text-xs font-bold text-[#001D3D] outline-none focus:border-blue-500 transition-all shadow-inner"
                />
                <p className="text-[9px] text-slate-400 italic">Protocol (https://) is required for Cloud Run.</p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={handleTestBackend}
                  disabled={isTestingBackend || !backendUrl}
                  className="flex-1 py-3 border border-slate-300 rounded-sm text-[9px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
                >
                  {isTestingBackend ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wifi className="w-3.5 h-3.5" />}
                  Test Ping
                </button>
                <button 
                  onClick={handleSaveBackend}
                  className="flex-1 py-3 bg-[#001D3D] text-white rounded-sm text-[9px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg"
                >
                  Save & Apply
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className={`${!state.isMobileOptimized ? 'min-w-[1024px]' : 'w-full'} min-h-screen relative`}>
        
        {state.showConsole && (
          <div className="fixed inset-y-0 right-0 w-full max-w-md bg-[#001D3D] z-[1000] shadow-2xl border-l border-white/10 flex flex-col no-print">
            <div className="p-6 bg-slate-900 border-b border-white/10 flex justify-between items-center">
              <h3 className="text-white font-black text-xs uppercase tracking-[0.3em] flex items-center gap-2"><Terminal className="w-4 h-4 text-blue-400" /> Technical Trace</h3>
              <div className="flex gap-2">
                <button onClick={() => { navigator.clipboard.writeText(JSON.stringify(logs)); setCopied(true); setTimeout(() => setCopied(false), 2000); }} className="text-white/50 hover:text-white transition-colors">
                  {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
                <button onClick={() => dispatch({ type: 'TOGGLE_CONSOLE' })} className="text-white/50 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6 font-mono text-[10px] space-y-4">
              {logs.map(log => (
                <div key={log.id} className="border-b border-white/5 pb-2">
                  <span className="text-white/30">[{log.timestamp}]</span> <span className={`font-black uppercase ${log.type === 'error' ? 'text-red-400' : log.type === 'success' ? 'text-green-400' : 'text-blue-400'}`}>[{log.type}]</span> <span className="text-white/80">{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {state.showArchitecture && <ArchitectureGuide onClose={() => dispatch({ type: 'TOGGLE_ARCHITECTURE' })} />}

        {state.view === 'dashboard' && (
          <div className="flex flex-col min-h-screen bg-[#001D3D]">
            <div className="bg-[#1e293b] py-3 px-4 flex justify-between items-center text-white border-b border-slate-700">
              <div className="flex gap-3">
                <button onClick={() => dispatch({ type: 'TOGGLE_MOBILE' })} className="flex items-center gap-2 px-4 py-1.5 rounded bg-slate-800 border border-slate-700 text-[9px] font-black uppercase tracking-widest">
                  {state.isMobileOptimized ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />} {state.isMobileOptimized ? 'Desktop' : 'Mobile'}
                </button>
                <button onClick={() => dispatch({ type: 'TOGGLE_MASTER_CODE' })} className="flex items-center gap-2 px-4 py-1.5 rounded bg-slate-800 border border-slate-700 text-[9px] font-black uppercase tracking-widest">
                  <FileCode className="w-3.5 h-3.5 text-green-400" /> Master Review
                </button>
                <button onClick={() => dispatch({ type: 'TOGGLE_CONSOLE' })} className="flex items-center gap-2 px-4 py-1.5 rounded bg-slate-800 border border-slate-700 text-[9px] font-black uppercase tracking-widest">
                  <Terminal className="w-3.5 h-3.5 text-blue-400" /> Trace
                </button>
              </div>
              <div className="flex items-center gap-4">
                <span className={`text-[8px] font-black uppercase tracking-widest ${state.isOnline ? 'text-green-400' : 'text-yellow-500'}`}>
                  {state.isOnline ? <><Wifi className="inline w-3 h-3 mr-1" /> Cloud Connected</> : <><AlertTriangle className="inline w-3 h-3 mr-1" /> Edge Mode</>}
                </span>
                <button 
                  onClick={() => dispatch({ type: 'TOGGLE_SETTINGS' })}
                  className="p-1 text-slate-400 hover:text-white transition-colors"
                  title="Connectivity Settings"
                >
                  <Settings className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="relative w-full h-[55vh] overflow-hidden">
               <img src={DASHBOARD_BACKSPLASH_URL} alt="ACCO" className="w-full h-full object-cover opacity-90" />
               <div className="absolute inset-0 bg-gradient-to-t from-[#001D3D] via-[#001D3D]/40 to-transparent"></div>
            </div>

            <div className="relative z-10 w-full max-w-7xl mx-auto px-4 -mt-48 pb-16 flex justify-center">
              <div className={`w-full ${state.isMobileOptimized ? 'max-w-md' : 'lg:w-[640px]'}`}>
                <div className="bg-[#0f172a]/80 backdrop-blur-xl border border-white/10 rounded-sm overflow-hidden shadow-2xl p-8 space-y-6">
                    <div className="border-b border-white/10 pb-4 mb-4">
                       <h2 className="text-white font-black text-xs uppercase tracking-[0.3em] flex items-center">
                         <PlayCircle className="w-4 h-4 mr-2 text-blue-400" /> Start Inspection
                       </h2>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Client</label>
                          <input 
                            type="text" 
                            placeholder="Ex. ZARA" 
                            value={state.client}
                            onChange={(e) => dispatch({ type: 'SET_FIELD', payload: { field: 'client', value: e.target.value } })}
                            className="w-full bg-white/5 border border-white/10 rounded-sm p-3 text-white text-xs outline-none focus:border-blue-500 transition-colors"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Technician</label>
                          <input 
                            type="text" 
                            placeholder="Ex. John Rossoni" 
                            value={state.technician}
                            onChange={(e) => dispatch({ type: 'SET_FIELD', payload: { field: 'technician', value: e.target.value } })}
                            className="w-full bg-white/5 border border-white/10 rounded-sm p-3 text-white text-xs outline-none focus:border-blue-500 transition-colors"
                          />
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Address</label>
                        <input 
                          type="text" 
                          placeholder="Ex. Thousand Oaks Mall, CA" 
                          value={state.address}
                          onChange={(e) => dispatch({ type: 'SET_FIELD', payload: { field: 'address', value: e.target.value } })}
                          className="w-full bg-white/5 border border-white/10 rounded-sm p-3 text-white text-xs outline-none focus:border-blue-500 transition-colors"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Protocol</label>
                        <input 
                          type="text" 
                          placeholder="Ex. Camera inspection pulling back from point of connection." 
                          value={state.protocol}
                          onChange={(e) => dispatch({ type: 'SET_FIELD', payload: { field: 'protocol', value: e.target.value } })}
                          className="w-full bg-white/5 border border-white/10 rounded-sm p-3 text-white text-xs outline-none focus:border-blue-500 transition-colors"
                        />
                      </div>
                    </div>
                    
                    <div 
                      onDragOver={onDragOver}
                      onDragLeave={onDragLeave}
                      onDrop={onDrop}
                      className={`relative border border-dashed rounded-sm p-10 flex flex-col items-center justify-center text-center transition-all ${state.isDragging ? 'border-blue-400 bg-blue-500/10' : 'border-white/10 bg-white/5'}`}
                    >
                      <input type="file" className="hidden" id="file-upload" accept="video/*" onChange={(e) => dispatch({ type: 'SET_FILE', payload: e.target.files?.[0] || null })} />
                      {state.file ? (
                        <div className="flex flex-col items-center">
                          <CheckCircle2 className="w-10 h-10 text-green-400 mb-3" />
                          <p className="text-white font-black uppercase text-xs truncate max-w-xs">{state.file.name}</p>
                          <button onClick={() => dispatch({ type: 'SET_FILE', payload: null })} className="mt-3 text-[8px] text-red-400 font-black uppercase">Replace</button>
                        </div>
                      ) : (
                        <>
                          <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center group mb-4">
                            <Upload className="w-6 h-6 text-blue-400 mb-3 group-hover:scale-110" />
                            <span className="px-8 py-2.5 bg-white text-[#001D3D] rounded-sm text-[9px] font-black uppercase tracking-[0.2em]">Upload Footage</span>
                          </label>
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Or Drag and Drop</span>
                        </>
                      )}
                    </div>

                    <button onClick={handleStartProcessing} disabled={!state.file} 
                      className={`w-full py-4 rounded-sm font-black text-white transition-all uppercase tracking-[0.2em] text-[10px] ${!state.file ? 'bg-white/5 text-white/20 cursor-not-allowed' : 'bg-[#D31245] hover:bg-red-700 shadow-xl'}`}
                    >
                      Process AI Analysis <ChevronRight className="inline ml-1 w-4 h-4" />
                    </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {state.view === 'processing' && (
          <div className="fixed inset-0 z-[100] bg-[#001D3D] flex items-center justify-center">
            <div className="absolute inset-0 opacity-15"><img src={PROCESSING_BACKSPLASH_URL} className="w-full h-full object-cover" alt="Processing" /></div>
            <div className="relative z-10 max-w-xl w-full text-center bg-white p-12 rounded-sm shadow-2xl mx-4">
              <div className="w-16 h-16 border-4 border-slate-100 border-t-[#00478B] rounded-full animate-spin mx-auto mb-8"></div>
              <h2 className="text-xl font-black text-slate-900 uppercase tracking-widest">{state.processingStage}</h2>
              <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden mt-8">
                <div className="bg-[#00478B] h-full transition-all duration-700" style={{ width: `${state.progress}%` }}></div>
              </div>
            </div>
          </div>
        )}

        {state.view === 'proposal-ask' && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#001D3D]/30 backdrop-blur-md">
            <div className="max-w-xl w-full bg-white p-12 rounded-sm shadow-2xl mx-4">
               <div className="text-center mb-10">
                 <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mb-6 mx-auto"><CheckCircle2 className="w-8 h-8 text-green-600" /></div>
                 <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">Assessment Ready</h2>
               </div>
               <div className="space-y-4">
                 <button onClick={() => { dispatch({ type: 'SET_PROPOSAL', payload: false }); dispatch({ type: 'SET_VIEW', payload: 'report' }); }} className="w-full bg-[#001D3D] text-white py-6 rounded-sm flex items-center justify-between px-8 font-black uppercase text-sm shadow-md group hover:bg-slate-800 transition-all">
                   <span className="flex items-center"><Eye className="w-5 h-5 mr-4 text-blue-300" /> View Report Only</span> <ArrowRight className="w-5 h-5" />
                 </button>
                  <button onClick={() => { dispatch({ type: 'SET_PROPOSAL', payload: true }); dispatch({ type: 'SET_VIEW', payload: 'report' }); }} className="w-full bg-white border border-slate-300 text-[#00478B] py-6 rounded-sm flex items-center justify-between px-8 font-black uppercase text-sm shadow-sm group hover:bg-slate-50 transition-all">
                    <span className="flex items-center"><FileText className="w-5 h-5 mr-4" /> Include Proposal</span> <ArrowRight className="w-5 h-5" />
                  </button>
               </div>
            </div>
          </div>
        )}

        {state.view === 'report' && state.reportData && (
          <InspectionReport 
            data={state.reportData} 
            frames={state.extractedFrames} 
            showProposal={state.withProposal}
            onBack={() => dispatch({ type: 'SET_VIEW', payload: 'dashboard' })} 
            onToggleArchitecture={() => {}}
          />
        )}
      </div>
    </Layout>
  );
};

export default App;